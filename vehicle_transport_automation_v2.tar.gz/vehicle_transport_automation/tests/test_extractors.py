"""Unit tests for auction invoice extractors."""
import pytest
import sys
from unittest.mock import Mock, patch, MagicMock
from datetime import datetime

sys.path.insert(0, '/home/claude/vehicle_transport_automation')

from models.vehicle import (
    AuctionSource, LocationType, VehicleType, TrailerType,
    Address, Vehicle, AuctionInvoice, TransportListing
)
from extractors.base import BaseExtractor
from extractors.iaa import IAAExtractor
from extractors.manheim import ManheimExtractor
from extractors.copart import CopartExtractor
from extractors import ExtractorManager


class TestBaseExtractor:
    """Tests for BaseExtractor utility methods."""
    
    def test_extract_vin(self):
        """Test VIN extraction."""
        text = "Vehicle VIN: 1C4SDHCT1NC218049 some other text"
        vin = BaseExtractor.extract_vin(text)
        assert vin == "1C4SDHCT1NC218049"
    
    def test_extract_vin_no_match(self):
        """Test VIN extraction with no VIN present."""
        text = "No VIN here"
        vin = BaseExtractor.extract_vin(text)
        assert vin is None
    
    def test_extract_vin_invalid_chars(self):
        """Test VIN extraction rejects I, O, Q characters."""
        # VINs cannot contain I, O, or Q
        text = "Invalid VIN: 1C4SDHCI1NC218049"  # Contains I
        vin = BaseExtractor.extract_vin(text)
        assert vin is None
    
    def test_extract_phone(self):
        """Test phone number extraction."""
        text = "Call us at (978) 555-1234 for help"
        phone = BaseExtractor.extract_phone(text)
        assert phone == "(978) 555-1234"
    
    def test_extract_phone_dash_format(self):
        """Test phone extraction with dash format."""
        text = "Phone: 978-555-1234"
        phone = BaseExtractor.extract_phone(text)
        assert phone == "978-555-1234"
    
    def test_extract_zip(self):
        """Test ZIP code extraction."""
        text = "Address: 77 Main St, Boston, MA 01432"
        zip_code = BaseExtractor.extract_zip(text)
        assert zip_code == "01432"
    
    def test_extract_zip_extended(self):
        """Test extended ZIP code extraction."""
        text = "ZIP: 01432-5678"
        zip_code = BaseExtractor.extract_zip(text)
        assert zip_code == "01432-5678"
    
    def test_parse_address(self):
        """Test address parsing."""
        text = "Located at Springfield, MA 01103"
        city, state, zip_code = BaseExtractor.parse_address(text)
        assert city == "Springfield"
        assert state == "MA"
        assert zip_code == "01103"
    
    def test_detect_vehicle_type_suv(self):
        """Test SUV detection."""
        vtype = BaseExtractor.detect_vehicle_type("HYUNDAI", "TUCSON")
        assert vtype == VehicleType.SUV
    
    def test_detect_vehicle_type_car(self):
        """Test CAR detection."""
        vtype = BaseExtractor.detect_vehicle_type("ALFA ROMEO", "GIULIA")
        assert vtype == VehicleType.CAR
    
    def test_detect_vehicle_type_truck(self):
        """Test TRUCK detection."""
        vtype = BaseExtractor.detect_vehicle_type("FORD", "F-150")
        assert vtype == VehicleType.TRUCK
    
    def test_detect_vehicle_type_default(self):
        """Test default vehicle type."""
        vtype = BaseExtractor.detect_vehicle_type("UNKNOWN", "MODEL")
        assert vtype == VehicleType.SUV  # Default
    
    def test_extract_year(self):
        """Test year extraction."""
        text = "2024 HYUNDAI TUCSON"
        year = BaseExtractor.extract_year(text)
        assert year == 2024
    
    def test_extract_mileage(self):
        """Test mileage extraction."""
        text = "Mileage: 71,489 miles"
        mileage = BaseExtractor.extract_mileage(text)
        assert mileage == 71489
    
    def test_extract_amount(self):
        """Test amount extraction."""
        text = "Total: $1,234.56"
        amount = BaseExtractor.extract_amount(text)
        assert amount == 1234.56
    
    def test_extract_amount_with_keyword(self):
        """Test amount extraction with keyword."""
        text = "Sale Price $5,000.00 Total $5,500.00"
        amount = BaseExtractor.extract_amount(text, "Total")
        assert amount == 5500.00


class TestIAAExtractor:
    """Tests for IAA document extractor."""
    
    def test_can_extract_positive(self):
        """Test detection of IAA documents."""
        extractor = IAAExtractor()
        text = "Insurance Auto Auctions Buyer Receipt"
        assert extractor.can_extract(text) is True
    
    def test_can_extract_negative(self):
        """Test rejection of non-IAA documents."""
        extractor = IAAExtractor()
        text = "Manheim Bill of Sale"
        assert extractor.can_extract(text) is False
    
    def test_source_property(self):
        """Test source property."""
        extractor = IAAExtractor()
        assert extractor.source == AuctionSource.IAA


class TestManheimExtractor:
    """Tests for Manheim document extractor."""
    
    def test_can_extract_positive(self):
        """Test detection of Manheim documents."""
        extractor = ManheimExtractor()
        text = "Manheim BILL OF SALE"
        assert extractor.can_extract(text) is True
    
    def test_can_extract_cox(self):
        """Test detection via Cox Automotive."""
        extractor = ManheimExtractor()
        text = "Cox Automotive Vehicle Release"
        assert extractor.can_extract(text) is True
    
    def test_can_extract_negative(self):
        """Test rejection of non-Manheim documents."""
        extractor = ManheimExtractor()
        text = "Copart Sales Receipt"
        assert extractor.can_extract(text) is False
    
    def test_detect_location_type_offsite(self):
        """Test OFFSITE location detection."""
        extractor = ManheimExtractor()
        text = "OFFSITE VEHICLE RELEASE - This vehicle is not located at a Manheim facility"
        location_type = extractor._detect_location_type(text)
        assert location_type == LocationType.OFFSITE
    
    def test_detect_location_type_onsite(self):
        """Test ONSITE location detection."""
        extractor = ManheimExtractor()
        text = "ONSITE VEHICLE RELEASE"
        location_type = extractor._detect_location_type(text)
        assert location_type == LocationType.ONSITE
    
    def test_detect_location_type_default(self):
        """Test default location type."""
        extractor = ManheimExtractor()
        text = "Just a regular document"
        location_type = extractor._detect_location_type(text)
        assert location_type == LocationType.ONSITE


class TestCopartExtractor:
    """Tests for Copart document extractor."""
    
    def test_can_extract_positive(self):
        """Test detection of Copart documents."""
        extractor = CopartExtractor()
        text = "Copart Sales Receipt/Bill of Sale MEMBER: 535527"
        assert extractor.can_extract(text) is True
    
    def test_can_extract_physical_address(self):
        """Test detection via PHYSICAL ADDRESS OF LOT."""
        extractor = CopartExtractor()
        text = "PHYSICAL ADDRESS OF LOT: 123 Main St"
        assert extractor.can_extract(text) is True
    
    def test_can_extract_negative(self):
        """Test rejection of non-Copart documents."""
        extractor = CopartExtractor()
        text = "Insurance Auto Auctions Buyer Receipt"
        assert extractor.can_extract(text) is False
    
    def test_source_property(self):
        """Test source property."""
        extractor = CopartExtractor()
        assert extractor.source == AuctionSource.COPART


class TestExtractorManager:
    """Tests for ExtractorManager."""
    
    def test_initialization(self):
        """Test manager initializes with all extractors."""
        manager = ExtractorManager()
        assert len(manager.extractors) == 3
        
        sources = [e.source for e in manager.extractors]
        assert AuctionSource.IAA in sources
        assert AuctionSource.MANHEIM in sources
        assert AuctionSource.COPART in sources
    
    def test_get_extractor_for_iaa_text(self):
        """Test extractor selection for IAA text."""
        manager = ExtractorManager()
        text = "Insurance Auto Auctions Buyer Receipt"
        extractor = manager.get_extractor_for_text(text)
        assert extractor is not None
        assert extractor.source == AuctionSource.IAA
    
    def test_get_extractor_for_manheim_text(self):
        """Test extractor selection for Manheim text."""
        manager = ExtractorManager()
        text = "Manheim BILL OF SALE"
        extractor = manager.get_extractor_for_text(text)
        assert extractor is not None
        assert extractor.source == AuctionSource.MANHEIM
    
    def test_get_extractor_for_copart_text(self):
        """Test extractor selection for Copart text."""
        manager = ExtractorManager()
        text = "Copart Sales Receipt MEMBER: 12345"
        extractor = manager.get_extractor_for_text(text)
        assert extractor is not None
        assert extractor.source == AuctionSource.COPART
    
    def test_get_extractor_for_unknown_text(self):
        """Test extractor selection for unknown text."""
        manager = ExtractorManager()
        text = "Unknown document type"
        extractor = manager.get_extractor_for_text(text)
        assert extractor is None


class TestDataModels:
    """Tests for data models."""
    
    def test_address_to_cd_stop(self):
        """Test Address conversion to CD stop format."""
        address = Address(
            name="Test Location",
            street="123 Main St",
            city="Boston",
            state="MA",
            postal_code="02101",
            phone="617-555-1234",
            contact_name="John Doe"
        )
        
        stop = address.to_cd_stop(1)
        
        assert stop["stopNumber"] == 1
        assert stop["city"] == "Boston"
        assert stop["state"] == "MA"
        assert stop["postalCode"] == "02101"
        assert stop["locationName"] == "Test Location"
        assert stop["address"] == "123 Main St"
        assert stop["phone"] == "617-555-1234"
        assert stop["contactName"] == "John Doe"
    
    def test_vehicle_to_cd_vehicle(self):
        """Test Vehicle conversion to CD vehicle format."""
        vehicle = Vehicle(
            vin="1C4SDHCT1NC218049",
            year=2022,
            make="DODGE",
            model="DURANGO",
            color="White",
            vehicle_type=VehicleType.SUV,
            is_inoperable=False,
            lot_number="LOT123"
        )
        
        cd_vehicle = vehicle.to_cd_vehicle()
        
        assert cd_vehicle["vin"] == "1C4SDHCT1NC218049"
        assert cd_vehicle["year"] == 2022
        assert cd_vehicle["make"] == "DODGE"
        assert cd_vehicle["model"] == "DURANGO"
        assert cd_vehicle["vehicleType"] == "SUV"
        assert cd_vehicle["isInoperable"] is False
        assert cd_vehicle["lotNumber"] == "LOT123"
        assert cd_vehicle["color"] == "White"
    
    def test_auction_invoice_reference_id_iaa(self):
        """Test reference ID for IAA."""
        invoice = AuctionInvoice(
            source=AuctionSource.IAA,
            buyer_id="123",
            buyer_name="Test",
            stock_number="000-12345"
        )
        assert invoice.reference_id == "000-12345"
    
    def test_auction_invoice_reference_id_manheim(self):
        """Test reference ID for Manheim."""
        invoice = AuctionInvoice(
            source=AuctionSource.MANHEIM,
            buyer_id="123",
            buyer_name="Test",
            release_id="ABC123"
        )
        assert invoice.reference_id == "ABC123"
    
    def test_auction_invoice_reference_id_copart(self):
        """Test reference ID for Copart."""
        invoice = AuctionInvoice(
            source=AuctionSource.COPART,
            buyer_id="123",
            buyer_name="Test",
            lot_number="91708175"
        )
        assert invoice.reference_id == "91708175"
    
    def test_transport_listing_to_cd_listing(self):
        """Test TransportListing conversion to CD listing format."""
        pickup = Address(
            name="Pickup Loc",
            city="Boston",
            state="MA",
            postal_code="02101"
        )
        
        delivery = Address(
            name="Broadway Motoring",
            city="Ayer",
            state="MA",
            postal_code="01432"
        )
        
        vehicle = Vehicle(
            vin="1C4SDHCT1NC218049",
            year=2022,
            make="DODGE",
            model="DURANGO",
            vehicle_type=VehicleType.SUV
        )
        
        invoice = AuctionInvoice(
            source=AuctionSource.IAA,
            buyer_id="123",
            buyer_name="Test",
            stock_number="000-12345",
            pickup_address=pickup,
            location_type=LocationType.ONSITE,
            vehicles=[vehicle]
        )
        
        listing = TransportListing(
            invoice=invoice,
            delivery_address=delivery,
            price=350.0,
            trailer_type=TrailerType.OPEN
        )
        
        cd_listing = listing.to_cd_listing(10000)
        
        assert cd_listing["trailerType"] == "OPEN"
        assert cd_listing["hasInOpVehicle"] is False
        assert cd_listing["price"]["total"] == 350.0
        assert cd_listing["price"]["cod"]["amount"] == 350.0
        assert len(cd_listing["stops"]) == 2
        assert len(cd_listing["vehicles"]) == 1
        assert cd_listing["marketplaces"][0]["marketplaceId"] == 10000
        assert "Stock#: 000-12345" in cd_listing["transportationReleaseNotes"]


# Run tests
if __name__ == "__main__":
    pytest.main([__file__, "-v"])
