# Vehicle Transport Automation

Automated system for extracting vehicle data from auction invoices (IAA, Manheim, Copart) and creating pickup tasks in ClickUp / transport listings on Central Dispatch.

## Features

- **Multi-source PDF extraction**: Automatically detects and extracts data from:
  - IAA (Insurance Auto Auctions) - Buyer Receipts
  - Manheim (Cox Automotive) - Bills of Sale & Vehicle Releases (ONSITE/OFFSITE)
  - Copart - Sales Receipts/Bills of Sale

- **Gate Pass extraction**: Extracts gate pass/PIN codes from email body text

- **ClickUp integration**: Creates pickup tasks with vehicle details

- **Central Dispatch integration**: Creates transport listings via Listings API V2

- **Email monitoring**: IMAP-based inbox monitoring with deduplication
  - Thread-aware (won't reprocess replies)
  - Attachment hash deduplication
  - SQLite-based idempotency storage

## Project Structure

```
vehicle_transport_automation/
├── README.md
├── main.py                      # CLI for single file processing
├── models/
│   └── vehicle.py               # Data models
├── extractors/
│   ├── __init__.py              # ExtractorManager
│   ├── base.py                  # BaseExtractor utilities
│   ├── iaa.py                   # IAA extractor
│   ├── manheim.py               # Manheim extractor
│   ├── copart.py                # Copart extractor
│   └── gate_pass.py             # Gate pass extraction from email body
├── services/
│   ├── orchestrator.py          # Main email processing pipeline ⭐
│   ├── clickup.py               # ClickUp API client
│   ├── central_dispatch.py      # Central Dispatch API client
│   ├── idempotency.py           # Deduplication storage
│   └── email_handler.py         # Legacy email handler
└── tests/
    └── test_extractors.py
```

## Installation

```bash
pip install pdfplumber requests
```

## Configuration

### Required Environment Variables

```bash
# Email (IMAP)
export EMAIL_IMAP_SERVER="imap.gmail.com"
export EMAIL_ADDRESS="info@y7agency.com"
export EMAIL_PASSWORD="your-app-password"
export EMAIL_FOLDER="INBOX"
export EMAIL_CHECK_INTERVAL="60"

# ClickUp (REQUIRED)
export CLICKUP_TOKEN="pk_..."           # Personal API token
export CLICKUP_LIST_ID="901317344729"   # Target list ID

# Central Dispatch (OPTIONAL)
export CD_CLIENT_ID="your-client-id"
export CD_CLIENT_SECRET="your-client-secret"
export CD_MARKETPLACE_ID="10000"
```

### Getting ClickUp List ID

From your ClickUp URL `https://app.clickup.com/90132095627/v/li/901317344729`:
- List ID = `901317344729` (the number after `/li/`)

### Getting Central Dispatch Credentials

Contact: datasyndicationsupport@centraldispatch.com

## Usage

### Email Processing (Recommended)

```bash
# Validate all credentials first
python -m services.orchestrator --validate

# Process unread emails once
python -m services.orchestrator --once

# Run as daemon (continuous monitoring)
python -m services.orchestrator --daemon

# Also create Central Dispatch listings
python -m services.orchestrator --daemon --with-cd
```

### Single File Processing

```bash
# Extract data only
python main.py extract invoice.pdf

# Create listing (dry run)
python main.py process invoice.pdf --dry-run

# Create listing on Central Dispatch
python main.py process invoice.pdf --price 350
```

## Deduplication Logic

The system prevents duplicate processing using:

1. **Thread Root ID**: Extracted from email headers (RFC 5322)
   - `References` header → first message ID is root
   - `In-Reply-To` header → that's the root
   - `Message-ID` → new thread

2. **Attachment Hash**: SHA256 of PDF content

3. **Idempotency Key**: `{thread_root_id}:{attachment_hash}`

Reply chains with the same PDF attachment are automatically skipped.

## Gate Pass Extraction

Gate pass codes are extracted from email body text. Supported formats:

- `Gate Pass: XXXXX`
- `Gate Pass Pin: XXXXX`
- `Release Code: XXXXX`
- `Pickup PIN: XXXXX`
- `Authorization Code: XXXXX`

The extracted gate pass is included in the ClickUp task description.

## ClickUp Task Format

Tasks are created with this format:

**Name:** `Pickup: 2024 HYUNDAI TUCSON | LOT 91708175`

**Description:**
```
**Source:** COPART
**VIN:** KM8J3CAL2RU123456
**Lot #:** 91708175
**Gate Pass:** ABC123
**Vehicle:** 2024 HYUNDAI TUCSON

**Pickup Address:**
Copart
123 Industrial Blvd
Springfield, MA 01103

**Notes:**
Location: ONSITE
Buyer: BROADWAY MOTORING INC
Total: $5,500.00
```

## API Endpoints

### ClickUp
- Base URL: `https://api.clickup.com/api/v2`
- Create Task: `POST /list/{list_id}/task`
- Auth: `Authorization: {token}` header

### Central Dispatch
- Token URL: `https://id.centraldispatch.com/connect/token`
- API Base: `https://marketplace-api.centraldispatch.com`
- Create Listing: `POST /listings`
- Auth: OAuth 2.0 Client Credentials

## Troubleshooting

### "Already processed" messages
This is expected! The system is correctly deduplicating reply chains.

### "Invalid PDF (invalid magic bytes)"
The attachment claims to be PDF but isn't. Check the actual file.

### ClickUp rate limiting
The client handles 429 responses automatically with backoff.

### Email connection issues
- For Gmail, use App Passwords (not regular password)
- Enable "Less secure app access" or use OAuth

## Security Notes

⚠️ **Never commit credentials to git!**

- Store all tokens in environment variables
- Use `.env` files with `.gitignore`
- Rotate tokens if exposed

## Support

- **ClickUp API**: https://clickup.com/api
- **Central Dispatch**: datasyndicationsupport@centraldispatch.com
