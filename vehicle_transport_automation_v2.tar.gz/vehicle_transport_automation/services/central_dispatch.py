"""Central Dispatch API client service."""
import os
import time
import json
import logging
from typing import Optional, Dict, Any
from datetime import datetime, timedelta
from dataclasses import dataclass
import requests

import sys
sys.path.insert(0, '/home/claude/vehicle_transport_automation')
from models.vehicle import TransportListing

logger = logging.getLogger(__name__)


@dataclass
class TokenInfo:
    """OAuth token information."""
    access_token: str
    expires_at: datetime
    refresh_token: Optional[str] = None
    
    @property
    def is_expired(self) -> bool:
        """Check if token is expired (with 5 min buffer)."""
        return datetime.utcnow() >= (self.expires_at - timedelta(minutes=5))


class CentralDispatchClient:
    """Client for Central Dispatch API.
    
    Authentication Flow:
    - Uses OAuth 2.0 Client Credentials flow
    - Token endpoint: https://id.centraldispatch.com/connect/token
    - API Base URL: https://marketplace-api.centraldispatch.com
    
    For testing:
    - Use staging environment and test marketplace ID
    - Staging API docs: https://stage-api-docs.centraldispatch.com
    """
    
    # Production endpoints
    PROD_TOKEN_URL = "https://id.centraldispatch.com/connect/token"
    PROD_API_BASE = "https://marketplace-api.centraldispatch.com"
    PROD_MARKETPLACE_ID = 10000  # Public marketplace
    
    # API version header
    API_VERSION_HEADER = "application/vnd.coxauto.v2+json"
    
    def __init__(
        self,
        client_id: str,
        client_secret: str,
        marketplace_id: Optional[int] = None,
        is_test: bool = False
    ):
        """Initialize the Central Dispatch client.
        
        Args:
            client_id: OAuth client ID
            client_secret: OAuth client secret  
            marketplace_id: Marketplace ID (use test ID for testing)
            is_test: Whether to use staging environment
        """
        self.client_id = client_id
        self.client_secret = client_secret
        self.marketplace_id = marketplace_id or self.PROD_MARKETPLACE_ID
        self.is_test = is_test
        
        # Use production endpoints (staging has same structure)
        self.token_url = self.PROD_TOKEN_URL
        self.api_base = self.PROD_API_BASE
        
        self._token_info: Optional[TokenInfo] = None
        self._session = requests.Session()
        
    def _get_access_token(self) -> str:
        """Get a valid access token, refreshing if necessary."""
        if self._token_info and not self._token_info.is_expired:
            return self._token_info.access_token
        
        # Request new token using client credentials
        data = {
            "grant_type": "client_credentials",
            "client_id": self.client_id,
            "client_secret": self.client_secret,
            "scope": "marketplace"
        }
        
        headers = {
            "Content-Type": "application/x-www-form-urlencoded"
        }
        
        try:
            response = self._session.post(
                self.token_url,
                data=data,
                headers=headers,
                timeout=30
            )
            response.raise_for_status()
            
            token_data = response.json()
            expires_in = token_data.get("expires_in", 3600)
            
            self._token_info = TokenInfo(
                access_token=token_data["access_token"],
                expires_at=datetime.utcnow() + timedelta(seconds=expires_in),
                refresh_token=token_data.get("refresh_token")
            )
            
            logger.info("Successfully obtained access token")
            return self._token_info.access_token
            
        except requests.RequestException as e:
            logger.error(f"Failed to obtain access token: {e}")
            raise AuthenticationError(f"Failed to authenticate: {e}")
    
    def _make_request(
        self,
        method: str,
        endpoint: str,
        data: Optional[Dict[str, Any]] = None,
        params: Optional[Dict[str, Any]] = None,
        extra_headers: Optional[Dict[str, str]] = None,
        retries: int = 3
    ) -> requests.Response:
        """Make an authenticated API request.
        
        Args:
            method: HTTP method (GET, POST, PUT, DELETE)
            endpoint: API endpoint (e.g., /listings)
            data: Request body data
            params: Query parameters
            extra_headers: Additional headers (e.g., If-Match for ETags)
            retries: Number of retry attempts
            
        Returns:
            Response object
        """
        url = f"{self.api_base}{endpoint}"
        
        for attempt in range(retries):
            try:
                token = self._get_access_token()
                
                headers = {
                    "Authorization": f"Bearer {token}",
                    "Content-Type": self.API_VERSION_HEADER,
                    "Accept": "application/json"
                }
                
                # Merge extra headers
                if extra_headers:
                    headers.update(extra_headers)
                
                response = self._session.request(
                    method=method,
                    url=url,
                    headers=headers,
                    json=data,
                    params=params,
                    timeout=60
                )
                
                # Handle token expiration
                if response.status_code == 401:
                    logger.warning("Token expired, refreshing...")
                    self._token_info = None
                    continue
                
                return response
                
            except requests.RequestException as e:
                logger.warning(f"Request failed (attempt {attempt + 1}/{retries}): {e}")
                if attempt < retries - 1:
                    time.sleep(2 ** attempt)  # Exponential backoff
                else:
                    raise
        
        raise APIError("Max retries exceeded")
    
    def create_listing(self, listing: TransportListing) -> Dict[str, Any]:
        """Create a new listing on Central Dispatch.
        
        Args:
            listing: TransportListing object with all required data
            
        Returns:
            Dict containing listing ID and response data
        """
        # Convert to API format
        listing_data = listing.to_cd_listing(self.marketplace_id)
        
        logger.info(f"Creating listing with data: {json.dumps(listing_data, indent=2)}")
        
        response = self._make_request("POST", "/listings", data=listing_data)
        
        if response.status_code == 201:
            # Get listing ID from Location header
            location = response.headers.get("Location", "")
            listing_id = location.split("/")[-1] if location else None
            etag = response.headers.get("ETag")
            
            logger.info(f"Successfully created listing: {listing_id}")
            
            return {
                "success": True,
                "listing_id": listing_id,
                "etag": etag,
                "location": location
            }
        else:
            error_data = self._parse_error_response(response)
            logger.error(f"Failed to create listing: {error_data}")
            raise APIError(f"Failed to create listing: {error_data}")
    
    def get_listing(self, listing_id: str) -> Dict[str, Any]:
        """Get a listing by ID.
        
        Args:
            listing_id: The listing ID
            
        Returns:
            Listing data
        """
        response = self._make_request("GET", f"/listings/{listing_id}")
        
        if response.status_code == 200:
            return response.json()
        else:
            error_data = self._parse_error_response(response)
            raise APIError(f"Failed to get listing: {error_data}")
    
    def update_listing(
        self,
        listing_id: str,
        listing: TransportListing,
        etag: str
    ) -> Dict[str, Any]:
        """Update an existing listing.
        
        Args:
            listing_id: The listing ID to update
            listing: Updated listing data
            etag: ETag from previous request (for optimistic locking)
            
        Returns:
            Updated listing data
        """
        listing_data = listing.to_cd_listing(self.marketplace_id)
        
        # Add If-Match header for optimistic locking
        extra_headers = {"If-Match": etag}
        
        response = self._make_request(
            "PUT", 
            f"/listings/{listing_id}", 
            data=listing_data,
            extra_headers=extra_headers
        )
        
        if response.status_code == 200:
            new_etag = response.headers.get("ETag")
            return {
                "success": True,
                "listing_id": listing_id,
                "etag": new_etag
            }
        else:
            error_data = self._parse_error_response(response)
            raise APIError(f"Failed to update listing: {error_data}")
    
    def delete_listing(self, listing_id: str) -> bool:
        """Delete a listing.
        
        Args:
            listing_id: The listing ID to delete
            
        Returns:
            True if successful
        """
        response = self._make_request("DELETE", f"/listings/{listing_id}")
        
        if response.status_code in (200, 204):
            logger.info(f"Successfully deleted listing: {listing_id}")
            return True
        else:
            error_data = self._parse_error_response(response)
            raise APIError(f"Failed to delete listing: {error_data}")
    
    def get_my_listings(
        self,
        status: Optional[str] = None,
        limit: int = 50
    ) -> Dict[str, Any]:
        """Get current user's listings.
        
        Args:
            status: Filter by status (e.g., 'ACTIVE', 'EXPIRED')
            limit: Maximum number of results
            
        Returns:
            List of listings
        """
        params = {"limit": limit}
        if status:
            params["status"] = status
        
        response = self._make_request("GET", "/listings/mine", params=params)
        
        if response.status_code == 200:
            return response.json()
        else:
            error_data = self._parse_error_response(response)
            raise APIError(f"Failed to get listings: {error_data}")
    
    def _parse_error_response(self, response: requests.Response) -> Dict[str, Any]:
        """Parse error response from API."""
        try:
            error_data = response.json()
        except json.JSONDecodeError:
            error_data = {"message": response.text}
        
        return {
            "status_code": response.status_code,
            "errors": error_data
        }
    
    def validate_credentials(self) -> bool:
        """Validate that credentials are working.
        
        Returns:
            True if credentials are valid
        """
        try:
            self._get_access_token()
            return True
        except AuthenticationError:
            return False


class AuthenticationError(Exception):
    """Raised when authentication fails."""
    pass


class APIError(Exception):
    """Raised when API request fails."""
    pass


# Helper function to create client from environment variables
def create_client_from_env() -> CentralDispatchClient:
    """Create a CentralDispatchClient from environment variables.
    
    Expected environment variables:
    - CD_CLIENT_ID: OAuth client ID
    - CD_CLIENT_SECRET: OAuth client secret
    - CD_MARKETPLACE_ID: (optional) Marketplace ID
    - CD_TEST_MODE: (optional) Set to 'true' for test mode
    """
    client_id = os.environ.get("CD_CLIENT_ID")
    client_secret = os.environ.get("CD_CLIENT_SECRET")
    
    if not client_id or not client_secret:
        raise ValueError("CD_CLIENT_ID and CD_CLIENT_SECRET environment variables must be set")
    
    marketplace_id = os.environ.get("CD_MARKETPLACE_ID")
    if marketplace_id:
        marketplace_id = int(marketplace_id)
    
    is_test = os.environ.get("CD_TEST_MODE", "false").lower() == "true"
    
    return CentralDispatchClient(
        client_id=client_id,
        client_secret=client_secret,
        marketplace_id=marketplace_id,
        is_test=is_test
    )
