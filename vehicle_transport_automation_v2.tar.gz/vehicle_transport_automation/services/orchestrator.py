"""
Email Worker Orchestrator - Main processing pipeline.

Coordinates:
1. Email fetching (IMAP)
2. Deduplication (idempotency store)
3. Gate pass extraction from email body
4. PDF extraction (IAA/Manheim/Copart)
5. ClickUp task creation
6. Optional: Central Dispatch listing creation

Usage:
    # Run once
    python -m services.orchestrator --once
    
    # Run as daemon
    python -m services.orchestrator --daemon
    
    # Validate all credentials
    python -m services.orchestrator --validate
"""
import os
import sys
import time
import email
import imaplib
import tempfile
import logging
import json
from email.header import decode_header
from typing import Optional, List, Dict, Any, Tuple
from dataclasses import dataclass, field, asdict
from datetime import datetime, timedelta
from pathlib import Path

sys.path.insert(0, '/home/claude/vehicle_transport_automation')

from models.vehicle import (
    AuctionInvoice, TransportListing, Address, 
    TrailerType, AuctionSource, LocationType
)
from extractors import extract_from_pdf
from extractors.gate_pass import GatePassExtractor, extract_text_from_email_body
from services.idempotency import IdempotencyStore
from services.clickup import (
    ClickUpClient, create_vehicle_pickup_task,
    create_client_from_env as create_clickup_from_env
)
from services.central_dispatch import (
    CentralDispatchClient, 
    create_client_from_env as create_cd_from_env
)

# Configure logging
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s [%(levelname)s] %(name)s: %(message)s'
)
logger = logging.getLogger(__name__)


# PDF magic bytes
PDF_MAGIC = b'%PDF'


@dataclass
class EmailConfig:
    """Email configuration."""
    imap_server: str
    email_address: str
    password: str
    folder: str = "INBOX"
    check_interval: int = 60
    
    @classmethod
    def from_env(cls) -> 'EmailConfig':
        """Create from environment variables."""
        return cls(
            imap_server=os.environ.get("EMAIL_IMAP_SERVER", "imap.gmail.com"),
            email_address=os.environ["EMAIL_ADDRESS"],
            password=os.environ["EMAIL_PASSWORD"],
            folder=os.environ.get("EMAIL_FOLDER", "INBOX"),
            check_interval=int(os.environ.get("EMAIL_CHECK_INTERVAL", "60"))
        )


@dataclass
class ProcessingResult:
    """Result of processing a single attachment."""
    success: bool
    attachment_name: str
    attachment_hash: str
    source_type: Optional[str] = None
    vehicle_info: Optional[Dict] = None
    gate_pass: Optional[str] = None
    clickup_task_id: Optional[str] = None
    cd_listing_id: Optional[str] = None
    skipped_reason: Optional[str] = None
    error: Optional[str] = None


@dataclass
class EmailProcessingResult:
    """Result of processing an email."""
    message_id: str
    thread_root_id: str
    subject: str
    sender: str
    processed_at: datetime
    attachments: List[ProcessingResult] = field(default_factory=list)
    gate_pass_from_body: Optional[str] = None
    
    @property
    def success_count(self) -> int:
        return sum(1 for a in self.attachments if a.success)
    
    @property
    def skipped_count(self) -> int:
        return sum(1 for a in self.attachments if a.skipped_reason)
    
    @property
    def error_count(self) -> int:
        return sum(1 for a in self.attachments if a.error)


class Orchestrator:
    """Main orchestrator for email processing pipeline."""
    
    # Default delivery address
    DEFAULT_DELIVERY = Address(
        name="Broadway Motoring Inc",
        street="77 Fitchburg Road",
        city="Ayer",
        state="MA",
        postal_code="01432",
        country="US"
    )
    
    DEFAULT_PRICE = 350.0
    
    def __init__(
        self,
        email_config: EmailConfig,
        idempotency_store: IdempotencyStore,
        clickup_client: Optional[ClickUpClient] = None,
        cd_client: Optional[CentralDispatchClient] = None,
        create_cd_listings: bool = False
    ):
        """Initialize orchestrator.
        
        Args:
            email_config: Email configuration
            idempotency_store: Deduplication store
            clickup_client: ClickUp client (required)
            cd_client: Central Dispatch client (optional)
            create_cd_listings: Whether to create CD listings
        """
        self.email_config = email_config
        self.store = idempotency_store
        self.clickup = clickup_client
        self.cd_client = cd_client
        self.create_cd_listings = create_cd_listings
        
        self._imap: Optional[imaplib.IMAP4_SSL] = None
    
    def connect_email(self) -> bool:
        """Connect to email server."""
        try:
            self._imap = imaplib.IMAP4_SSL(self.email_config.imap_server)
            self._imap.login(
                self.email_config.email_address,
                self.email_config.password
            )
            logger.info(f"Connected to {self.email_config.imap_server}")
            return True
        except Exception as e:
            logger.error(f"Email connection failed: {e}")
            return False
    
    def disconnect_email(self):
        """Disconnect from email server."""
        if self._imap:
            try:
                self._imap.logout()
            except:
                pass
            self._imap = None
    
    def fetch_unread_emails(self) -> List[Tuple[str, email.message.Message]]:
        """Fetch unread emails from configured folder."""
        if not self._imap:
            if not self.connect_email():
                return []
        
        try:
            self._imap.select(self.email_config.folder)
            status, messages = self._imap.search(None, "UNSEEN")
            
            if status != "OK":
                logger.error("Failed to search emails")
                return []
            
            email_ids = messages[0].split()
            emails = []
            
            for email_id in email_ids:
                status, msg_data = self._imap.fetch(email_id, "(RFC822)")
                if status == "OK":
                    raw_email = msg_data[0][1]
                    msg = email.message_from_bytes(raw_email)
                    emails.append((email_id.decode(), msg))
            
            logger.info(f"Fetched {len(emails)} unread emails")
            return emails
            
        except Exception as e:
            logger.error(f"Error fetching emails: {e}")
            self._imap = None
            return []
    
    def mark_as_read(self, email_id: str):
        """Mark email as read."""
        if self._imap:
            try:
                self._imap.store(email_id, '+FLAGS', '\\Seen')
            except Exception as e:
                logger.warning(f"Failed to mark as read: {e}")
    
    def process_email(
        self,
        email_id: str,
        msg: email.message.Message
    ) -> EmailProcessingResult:
        """Process a single email.
        
        Args:
            email_id: IMAP email ID
            msg: Email message
            
        Returns:
            Processing result
        """
        # Extract headers for threading
        message_id = msg.get("Message-ID", "")
        in_reply_to = msg.get("In-Reply-To")
        references = msg.get("References")
        subject = self._decode_header(msg.get("Subject", ""))
        sender = msg.get("From", "")
        
        # Determine thread root
        thread_root_id = IdempotencyStore.extract_thread_root_id(
            message_id, in_reply_to, references
        )
        
        result = EmailProcessingResult(
            message_id=message_id,
            thread_root_id=thread_root_id,
            subject=subject,
            sender=sender,
            processed_at=datetime.utcnow()
        )
        
        logger.info(f"Processing: '{subject}' from {sender}")
        logger.debug(f"Thread root: {thread_root_id}")
        
        # Extract gate pass from email body
        try:
            body_text = extract_text_from_email_body(msg)
            gate_pass = GatePassExtractor.extract_primary(body_text)
            if gate_pass:
                result.gate_pass_from_body = gate_pass
                logger.info(f"Found gate pass in body: {gate_pass}")
        except Exception as e:
            logger.warning(f"Failed to extract gate pass from body: {e}")
        
        # Extract and process PDF attachments
        attachments = self._extract_pdf_attachments(msg)
        
        if not attachments:
            logger.info("No PDF attachments found")
            return result
        
        for filename, content in attachments:
            attachment_result = self._process_attachment(
                filename=filename,
                content=content,
                thread_root_id=thread_root_id,
                message_id=message_id,
                gate_pass=result.gate_pass_from_body
            )
            result.attachments.append(attachment_result)
        
        return result
    
    def _process_attachment(
        self,
        filename: str,
        content: bytes,
        thread_root_id: str,
        message_id: str,
        gate_pass: Optional[str]
    ) -> ProcessingResult:
        """Process a single PDF attachment.
        
        Args:
            filename: Attachment filename
            content: PDF content bytes
            thread_root_id: Thread root ID
            message_id: Current message ID
            gate_pass: Gate pass from email body
            
        Returns:
            Processing result
        """
        # Compute hash for deduplication
        attachment_hash = IdempotencyStore.compute_attachment_hash(content)
        
        result = ProcessingResult(
            success=False,
            attachment_name=filename,
            attachment_hash=attachment_hash,
            gate_pass=gate_pass
        )
        
        logger.info(f"Processing attachment: {filename} (hash: {attachment_hash[:12]}...)")
        
        # Check for duplicates
        is_processed, existing_id = self.store.is_attachment_processed_in_thread(
            thread_root_id, attachment_hash
        )
        
        if is_processed:
            result.skipped_reason = f"Already processed (existing: {existing_id})"
            logger.info(f"Skipping duplicate: {filename}")
            return result
        
        # Validate PDF magic bytes
        if not content.startswith(PDF_MAGIC):
            result.skipped_reason = "Not a valid PDF (invalid magic bytes)"
            logger.warning(f"Invalid PDF: {filename}")
            return result
        
        # Save to temp file and extract
        try:
            with tempfile.NamedTemporaryFile(suffix='.pdf', delete=False) as f:
                f.write(content)
                temp_path = f.name
            
            invoice = extract_from_pdf(temp_path)
            
        except Exception as e:
            result.error = f"PDF extraction failed: {e}"
            logger.error(result.error)
            return result
        finally:
            try:
                os.unlink(temp_path)
            except:
                pass
        
        if not invoice:
            result.error = "Could not extract invoice data (unknown document type)"
            logger.warning(result.error)
            return result
        
        if not invoice.vehicles:
            result.error = "No vehicles found in invoice"
            logger.warning(result.error)
            return result
        
        # Set extracted data
        result.source_type = invoice.source.value
        vehicle = invoice.vehicles[0]
        result.vehicle_info = {
            "vin": vehicle.vin,
            "year": vehicle.year,
            "make": vehicle.make,
            "model": vehicle.model,
            "vehicle_type": vehicle.vehicle_type.value
        }
        
        logger.info(f"Extracted: {invoice.source.value} - {vehicle.year} {vehicle.make} {vehicle.model}")
        
        # Create ClickUp task
        if self.clickup:
            try:
                task_result = self._create_clickup_task(invoice, gate_pass)
                result.clickup_task_id = task_result.get("task_id")
                logger.info(f"Created ClickUp task: {result.clickup_task_id}")
            except Exception as e:
                logger.error(f"ClickUp task creation failed: {e}")
                # Continue - don't fail the whole process
        
        # Create Central Dispatch listing (optional)
        if self.create_cd_listings and self.cd_client:
            try:
                listing_result = self._create_cd_listing(invoice)
                result.cd_listing_id = listing_result.get("listing_id")
                logger.info(f"Created CD listing: {result.cd_listing_id}")
            except Exception as e:
                logger.error(f"CD listing creation failed: {e}")
        
        # Mark as processed
        result_type = "clickup_task" if result.clickup_task_id else "extracted"
        result_id = result.clickup_task_id or f"extracted-{attachment_hash[:12]}"
        
        self.store.mark_processed(
            thread_root_id=thread_root_id,
            message_id=message_id,
            attachment_hash=attachment_hash,
            source_type=result.source_type,
            result_type=result_type,
            result_id=result_id,
            metadata=json.dumps(result.vehicle_info)
        )
        
        result.success = True
        return result
    
    def _create_clickup_task(
        self,
        invoice: AuctionInvoice,
        gate_pass: Optional[str]
    ) -> Dict[str, Any]:
        """Create ClickUp task from invoice."""
        vehicle = invoice.vehicles[0]
        vehicle_desc = f"{vehicle.year} {vehicle.make} {vehicle.model}"
        
        # Build pickup address string
        pickup_addr = "Address not extracted"
        if invoice.pickup_address:
            parts = []
            if invoice.pickup_address.name:
                parts.append(invoice.pickup_address.name)
            if invoice.pickup_address.street:
                parts.append(invoice.pickup_address.street)
            parts.append(f"{invoice.pickup_address.city}, {invoice.pickup_address.state} {invoice.pickup_address.postal_code}")
            pickup_addr = "\n".join(parts)
        
        # Lot number varies by source
        lot_number = invoice.reference_id or "N/A"
        
        # Additional notes
        notes_parts = []
        if invoice.location_type:
            notes_parts.append(f"Location: {invoice.location_type.value}")
        if invoice.buyer_name:
            notes_parts.append(f"Buyer: {invoice.buyer_name}")
        if invoice.total_amount:
            notes_parts.append(f"Total: ${invoice.total_amount:,.2f}")
        
        return create_vehicle_pickup_task(
            client=self.clickup,
            vin=vehicle.vin,
            lot_number=lot_number,
            vehicle_desc=vehicle_desc,
            pickup_address=pickup_addr,
            gate_pass=gate_pass,
            source=invoice.source.value,
            additional_notes="\n".join(notes_parts) if notes_parts else None
        )
    
    def _create_cd_listing(self, invoice: AuctionInvoice) -> Dict[str, Any]:
        """Create Central Dispatch listing from invoice."""
        listing = TransportListing(
            invoice=invoice,
            delivery_address=self.DEFAULT_DELIVERY,
            price=self.DEFAULT_PRICE,
            trailer_type=TrailerType.OPEN,
            available_date=datetime.utcnow(),
            expiration_date=datetime.utcnow() + timedelta(days=14)
        )
        listing.external_id = f"{invoice.source.value}-{invoice.reference_id or 'UNKNOWN'}"
        
        return self.cd_client.create_listing(listing)
    
    def _extract_pdf_attachments(
        self,
        msg: email.message.Message
    ) -> List[Tuple[str, bytes]]:
        """Extract PDF attachments from email."""
        attachments = []
        
        for part in msg.walk():
            content_type = part.get_content_type()
            content_disposition = str(part.get("Content-Disposition", ""))
            
            # Check if it's an attachment
            if "attachment" not in content_disposition and content_type != "application/pdf":
                # Also check for inline PDFs
                if content_type not in ("application/pdf", "application/octet-stream"):
                    continue
            
            filename = part.get_filename()
            if filename:
                filename = self._decode_header(filename)
            else:
                filename = "attachment.pdf"
            
            content = part.get_payload(decode=True)
            if not content:
                continue
            
            # Validate it's actually a PDF by checking magic bytes
            if content.startswith(PDF_MAGIC):
                attachments.append((filename, content))
            elif filename.lower().endswith('.pdf'):
                # File claims to be PDF but wrong magic bytes
                logger.warning(f"File {filename} has .pdf extension but invalid content")
        
        return attachments
    
    @staticmethod
    def _decode_header(header: str) -> str:
        """Decode email header value."""
        if not header:
            return ""
        
        decoded_parts = decode_header(header)
        result = ""
        for content, encoding in decoded_parts:
            if isinstance(content, bytes):
                result += content.decode(encoding or 'utf-8', errors='replace')
            else:
                result += content
        return result
    
    def run_once(self) -> List[EmailProcessingResult]:
        """Process all unread emails once."""
        results = []
        
        if not self.connect_email():
            return results
        
        try:
            emails = self.fetch_unread_emails()
            
            for email_id, msg in emails:
                try:
                    result = self.process_email(email_id, msg)
                    results.append(result)
                    
                    # Log summary
                    logger.info(
                        f"Processed '{result.subject}': "
                        f"{result.success_count} success, "
                        f"{result.skipped_count} skipped, "
                        f"{result.error_count} errors"
                    )
                    
                except Exception as e:
                    logger.error(f"Failed to process email {email_id}: {e}")
                
                # Mark as read after processing (even if errors)
                self.mark_as_read(email_id)
            
        finally:
            self.disconnect_email()
        
        return results
    
    def run_daemon(self):
        """Run continuously, checking for new emails."""
        logger.info(
            f"Starting daemon (check interval: {self.email_config.check_interval}s)"
        )
        
        while True:
            try:
                results = self.run_once()
                
                if results:
                    total_success = sum(r.success_count for r in results)
                    total_skipped = sum(r.skipped_count for r in results)
                    logger.info(
                        f"Cycle complete: {len(results)} emails, "
                        f"{total_success} tasks created, "
                        f"{total_skipped} duplicates skipped"
                    )
                
            except KeyboardInterrupt:
                logger.info("Stopping daemon")
                break
            except Exception as e:
                logger.error(f"Daemon cycle error: {e}")
            
            time.sleep(self.email_config.check_interval)


def validate_all_credentials() -> Dict[str, bool]:
    """Validate all configured credentials."""
    results = {}
    
    # Email
    try:
        config = EmailConfig.from_env()
        imap = imaplib.IMAP4_SSL(config.imap_server)
        imap.login(config.email_address, config.password)
        imap.logout()
        results["email"] = True
        logger.info("✓ Email credentials valid")
    except Exception as e:
        results["email"] = False
        logger.error(f"✗ Email: {e}")
    
    # ClickUp
    try:
        client = create_clickup_from_env()
        results["clickup"] = client.validate_credentials()
        if results["clickup"]:
            logger.info("✓ ClickUp credentials valid")
        else:
            logger.error("✗ ClickUp: Invalid token")
    except Exception as e:
        results["clickup"] = False
        logger.error(f"✗ ClickUp: {e}")
    
    # Central Dispatch (optional)
    try:
        client = create_cd_from_env()
        results["central_dispatch"] = client.validate_credentials()
        if results["central_dispatch"]:
            logger.info("✓ Central Dispatch credentials valid")
        else:
            logger.error("✗ Central Dispatch: Invalid credentials")
    except ValueError:
        results["central_dispatch"] = None  # Not configured
        logger.info("- Central Dispatch: Not configured")
    except Exception as e:
        results["central_dispatch"] = False
        logger.error(f"✗ Central Dispatch: {e}")
    
    return results


def main():
    """Main entry point."""
    import argparse
    
    parser = argparse.ArgumentParser(description="Email processing orchestrator")
    parser.add_argument("--daemon", action="store_true", help="Run as daemon")
    parser.add_argument("--once", action="store_true", help="Process once and exit")
    parser.add_argument("--validate", action="store_true", help="Validate credentials")
    parser.add_argument("--with-cd", action="store_true", help="Also create CD listings")
    parser.add_argument("--db", default="processed_emails.db", help="Idempotency DB path")
    
    args = parser.parse_args()
    
    if args.validate:
        results = validate_all_credentials()
        all_ok = all(v for v in results.values() if v is not None)
        sys.exit(0 if all_ok else 1)
    
    # Load configuration
    try:
        email_config = EmailConfig.from_env()
    except KeyError as e:
        logger.error(f"Missing env var: {e}")
        sys.exit(1)
    
    # Initialize stores and clients
    store = IdempotencyStore(args.db)
    
    try:
        clickup = create_clickup_from_env()
    except ValueError as e:
        logger.error(f"ClickUp not configured: {e}")
        sys.exit(1)
    
    cd_client = None
    if args.with_cd:
        try:
            cd_client = create_cd_from_env()
        except ValueError as e:
            logger.warning(f"CD not configured: {e}")
    
    # Create orchestrator
    orchestrator = Orchestrator(
        email_config=email_config,
        idempotency_store=store,
        clickup_client=clickup,
        cd_client=cd_client,
        create_cd_listings=args.with_cd
    )
    
    if args.daemon:
        orchestrator.run_daemon()
    else:
        results = orchestrator.run_once()
        
        # Print summary
        for r in results:
            print(f"\n{r.subject}")
            print(f"  Thread: {r.thread_root_id[:40]}...")
            if r.gate_pass_from_body:
                print(f"  Gate Pass: {r.gate_pass_from_body}")
            for a in r.attachments:
                status = "✓" if a.success else ("⊘" if a.skipped_reason else "✗")
                print(f"  {status} {a.attachment_name}")
                if a.clickup_task_id:
                    print(f"      ClickUp: {a.clickup_task_id}")
                if a.skipped_reason:
                    print(f"      Skipped: {a.skipped_reason}")
                if a.error:
                    print(f"      Error: {a.error}")


if __name__ == "__main__":
    main()
