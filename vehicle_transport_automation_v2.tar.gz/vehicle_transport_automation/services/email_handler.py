"""
Email Handler Service - Monitor inbox and process auction invoice attachments.

This module provides functionality to:
1. Connect to an email inbox (IMAP)
2. Monitor for new emails with PDF attachments
3. Extract PDFs and route to appropriate extractors
4. Create Central Dispatch listings

Configuration:
    Set environment variables:
    - EMAIL_IMAP_SERVER: IMAP server address
    - EMAIL_ADDRESS: Email address to monitor
    - EMAIL_PASSWORD: Email password or app password
    - EMAIL_FOLDER: Folder to monitor (default: INBOX)
    
Usage:
    # As a service
    python -m services.email_handler --daemon
    
    # Process once
    python -m services.email_handler --once
"""
import os
import sys
import time
import email
import imaplib
import logging
import tempfile
from email.header import decode_header
from typing import List, Optional, Tuple
from pathlib import Path
from dataclasses import dataclass
from datetime import datetime

sys.path.insert(0, '/home/claude/vehicle_transport_automation')

from extractors import extract_from_pdf
from models.vehicle import AuctionInvoice, TransportListing, Address, TrailerType
from services.central_dispatch import CentralDispatchClient, create_client_from_env

logger = logging.getLogger(__name__)


@dataclass
class EmailConfig:
    """Email configuration."""
    imap_server: str
    email_address: str
    password: str
    folder: str = "INBOX"
    check_interval: int = 60  # seconds
    
    @classmethod
    def from_env(cls) -> 'EmailConfig':
        """Create config from environment variables."""
        return cls(
            imap_server=os.environ.get("EMAIL_IMAP_SERVER", "imap.gmail.com"),
            email_address=os.environ["EMAIL_ADDRESS"],
            password=os.environ["EMAIL_PASSWORD"],
            folder=os.environ.get("EMAIL_FOLDER", "INBOX"),
            check_interval=int(os.environ.get("EMAIL_CHECK_INTERVAL", "60"))
        )


@dataclass
class ProcessedEmail:
    """Result of processing an email."""
    message_id: str
    subject: str
    sender: str
    received_date: datetime
    attachments_processed: int
    invoices_extracted: int
    listings_created: int
    errors: List[str]


class EmailHandler:
    """Handles email monitoring and PDF extraction."""
    
    def __init__(
        self,
        config: EmailConfig,
        delivery_address: Address,
        default_price: float = 350.0,
        cd_client: Optional[CentralDispatchClient] = None
    ):
        """Initialize email handler.
        
        Args:
            config: Email configuration
            delivery_address: Default delivery address for all listings
            default_price: Default transport price
            cd_client: Central Dispatch client (optional)
        """
        self.config = config
        self.delivery_address = delivery_address
        self.default_price = default_price
        self.cd_client = cd_client
        self._connection: Optional[imaplib.IMAP4_SSL] = None
    
    def connect(self) -> bool:
        """Connect to the email server.
        
        Returns:
            True if connection successful
        """
        try:
            self._connection = imaplib.IMAP4_SSL(self.config.imap_server)
            self._connection.login(self.config.email_address, self.config.password)
            logger.info(f"Connected to {self.config.imap_server}")
            return True
        except Exception as e:
            logger.error(f"Failed to connect: {e}")
            return False
    
    def disconnect(self):
        """Disconnect from the email server."""
        if self._connection:
            try:
                self._connection.logout()
            except:
                pass
            self._connection = None
    
    def get_unread_emails(self) -> List[Tuple[str, email.message.Message]]:
        """Get all unread emails from the configured folder.
        
        Returns:
            List of (message_id, email_message) tuples
        """
        if not self._connection:
            if not self.connect():
                return []
        
        try:
            self._connection.select(self.config.folder)
            
            # Search for unread emails
            status, messages = self._connection.search(None, "UNSEEN")
            
            if status != "OK":
                logger.error("Failed to search emails")
                return []
            
            email_ids = messages[0].split()
            emails = []
            
            for email_id in email_ids:
                status, msg_data = self._connection.fetch(email_id, "(RFC822)")
                if status == "OK":
                    raw_email = msg_data[0][1]
                    msg = email.message_from_bytes(raw_email)
                    emails.append((email_id.decode(), msg))
            
            return emails
            
        except Exception as e:
            logger.error(f"Error getting emails: {e}")
            self._connection = None
            return []
    
    def extract_pdf_attachments(self, msg: email.message.Message) -> List[Tuple[str, bytes]]:
        """Extract PDF attachments from an email.
        
        Args:
            msg: Email message
            
        Returns:
            List of (filename, content) tuples
        """
        attachments = []
        
        for part in msg.walk():
            content_type = part.get_content_type()
            content_disposition = str(part.get("Content-Disposition", ""))
            
            if "attachment" in content_disposition or content_type == "application/pdf":
                filename = part.get_filename()
                if filename:
                    # Decode filename if needed
                    decoded_parts = decode_header(filename)
                    filename = ""
                    for content, encoding in decoded_parts:
                        if isinstance(content, bytes):
                            filename += content.decode(encoding or 'utf-8')
                        else:
                            filename += content
                
                if filename and filename.lower().endswith('.pdf'):
                    content = part.get_payload(decode=True)
                    if content:
                        attachments.append((filename, content))
        
        return attachments
    
    def process_email(self, email_id: str, msg: email.message.Message) -> ProcessedEmail:
        """Process a single email.
        
        Args:
            email_id: Email ID
            msg: Email message
            
        Returns:
            ProcessedEmail with results
        """
        # Get email metadata
        subject = msg.get("Subject", "")
        sender = msg.get("From", "")
        date_str = msg.get("Date", "")
        
        # Decode subject if needed
        decoded_subject = decode_header(subject)
        subject = ""
        for content, encoding in decoded_subject:
            if isinstance(content, bytes):
                subject += content.decode(encoding or 'utf-8')
            else:
                subject += content
        
        result = ProcessedEmail(
            message_id=email_id,
            subject=subject,
            sender=sender,
            received_date=datetime.now(),
            attachments_processed=0,
            invoices_extracted=0,
            listings_created=0,
            errors=[]
        )
        
        logger.info(f"Processing email: {subject} from {sender}")
        
        # Extract PDF attachments
        attachments = self.extract_pdf_attachments(msg)
        result.attachments_processed = len(attachments)
        
        if not attachments:
            logger.info("No PDF attachments found")
            return result
        
        # Process each attachment
        for filename, content in attachments:
            try:
                invoice, listing_id = self._process_attachment(filename, content)
                
                if invoice:
                    result.invoices_extracted += 1
                    
                if listing_id:
                    result.listings_created += 1
                    logger.info(f"Created listing {listing_id} from {filename}")
                    
            except Exception as e:
                error_msg = f"Error processing {filename}: {e}"
                logger.error(error_msg)
                result.errors.append(error_msg)
        
        return result
    
    def _process_attachment(
        self,
        filename: str,
        content: bytes
    ) -> Tuple[Optional[AuctionInvoice], Optional[str]]:
        """Process a PDF attachment.
        
        Args:
            filename: PDF filename
            content: PDF content
            
        Returns:
            Tuple of (invoice, listing_id)
        """
        # Save to temp file
        with tempfile.NamedTemporaryFile(suffix='.pdf', delete=False) as f:
            f.write(content)
            temp_path = f.name
        
        try:
            # Extract invoice data
            invoice = extract_from_pdf(temp_path)
            
            if not invoice:
                logger.warning(f"Could not extract data from {filename}")
                return None, None
            
            if not invoice.vehicles:
                logger.warning(f"No vehicles found in {filename}")
                return invoice, None
            
            # Create listing
            listing = TransportListing(
                invoice=invoice,
                delivery_address=self.delivery_address,
                price=self.default_price,
                trailer_type=TrailerType.OPEN
            )
            
            # Set external ID for tracking
            listing.external_id = f"{invoice.source.value}-{invoice.reference_id or filename}"
            
            # Create on Central Dispatch
            if self.cd_client:
                try:
                    result = self.cd_client.create_listing(listing)
                    return invoice, result.get("listing_id")
                except Exception as e:
                    logger.error(f"Failed to create listing: {e}")
                    return invoice, None
            else:
                logger.info("No CD client configured - listing not created")
                return invoice, None
                
        finally:
            # Cleanup temp file
            try:
                os.unlink(temp_path)
            except:
                pass
    
    def mark_as_read(self, email_id: str):
        """Mark an email as read.
        
        Args:
            email_id: Email ID to mark
        """
        if self._connection:
            try:
                self._connection.store(email_id, '+FLAGS', '\\Seen')
            except Exception as e:
                logger.error(f"Failed to mark email as read: {e}")
    
    def run_once(self) -> List[ProcessedEmail]:
        """Process all unread emails once.
        
        Returns:
            List of processing results
        """
        results = []
        
        if not self.connect():
            return results
        
        try:
            emails = self.get_unread_emails()
            logger.info(f"Found {len(emails)} unread emails")
            
            for email_id, msg in emails:
                result = self.process_email(email_id, msg)
                results.append(result)
                
                # Mark as read after processing
                self.mark_as_read(email_id)
            
        finally:
            self.disconnect()
        
        return results
    
    def run_daemon(self):
        """Run as a daemon, continuously checking for new emails."""
        logger.info(f"Starting email handler daemon (check every {self.config.check_interval}s)")
        
        while True:
            try:
                results = self.run_once()
                
                if results:
                    total_invoices = sum(r.invoices_extracted for r in results)
                    total_listings = sum(r.listings_created for r in results)
                    logger.info(f"Processed {len(results)} emails, extracted {total_invoices} invoices, created {total_listings} listings")
                
            except KeyboardInterrupt:
                logger.info("Stopping daemon")
                break
            except Exception as e:
                logger.error(f"Error in daemon loop: {e}")
            
            time.sleep(self.config.check_interval)


def main():
    """Main entry point for email handler."""
    import argparse
    
    parser = argparse.ArgumentParser(description="Email handler for auction invoices")
    parser.add_argument("--daemon", action="store_true", help="Run as daemon")
    parser.add_argument("--once", action="store_true", help="Process once and exit")
    
    args = parser.parse_args()
    
    # Configure logging
    logging.basicConfig(
        level=logging.INFO,
        format='%(asctime)s - %(name)s - %(levelname)s - %(message)s'
    )
    
    # Load configuration
    try:
        config = EmailConfig.from_env()
    except KeyError as e:
        logger.error(f"Missing required environment variable: {e}")
        sys.exit(1)
    
    # Default delivery address
    delivery_address = Address(
        name="Broadway Motoring Inc",
        street="77 Fitchburg Road",
        city="Ayer",
        state="MA",
        postal_code="01432",
        country="US"
    )
    
    # Create CD client
    try:
        cd_client = create_client_from_env()
    except ValueError:
        logger.warning("Central Dispatch credentials not configured - listings will not be created")
        cd_client = None
    
    # Create handler
    handler = EmailHandler(
        config=config,
        delivery_address=delivery_address,
        cd_client=cd_client
    )
    
    if args.daemon:
        handler.run_daemon()
    else:
        results = handler.run_once()
        print(f"Processed {len(results)} emails")
        for r in results:
            print(f"  - {r.subject}: {r.invoices_extracted} invoices, {r.listings_created} listings")


if __name__ == "__main__":
    main()
