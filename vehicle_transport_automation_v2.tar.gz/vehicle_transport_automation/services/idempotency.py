"""
Idempotency storage for email deduplication.

Prevents duplicate processing of:
- Reply chains (same thread)
- Reprocessed emails after restart
- Forwarded duplicates

Uses SQLite for persistence across restarts.
"""
import sqlite3
import hashlib
import logging
from pathlib import Path
from typing import Optional, Tuple
from datetime import datetime
from contextlib import contextmanager

logger = logging.getLogger(__name__)


class IdempotencyStore:
    """SQLite-based idempotency storage for email deduplication."""
    
    def __init__(self, db_path: str = "processed_emails.db"):
        """Initialize the store.
        
        Args:
            db_path: Path to SQLite database file
        """
        self.db_path = Path(db_path)
        self._init_db()
    
    def _init_db(self):
        """Initialize database schema."""
        with self._get_connection() as conn:
            conn.execute("""
                CREATE TABLE IF NOT EXISTS processed_items (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    idempotency_key TEXT UNIQUE NOT NULL,
                    thread_root_id TEXT,
                    message_id TEXT,
                    attachment_hash TEXT,
                    source_type TEXT,
                    result_type TEXT,
                    result_id TEXT,
                    processed_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                    metadata TEXT
                )
            """)
            conn.execute("""
                CREATE INDEX IF NOT EXISTS idx_thread_root 
                ON processed_items(thread_root_id)
            """)
            conn.execute("""
                CREATE INDEX IF NOT EXISTS idx_attachment_hash 
                ON processed_items(attachment_hash)
            """)
            conn.commit()
    
    @contextmanager
    def _get_connection(self):
        """Get database connection with context manager."""
        conn = sqlite3.connect(str(self.db_path))
        conn.row_factory = sqlite3.Row
        try:
            yield conn
        finally:
            conn.close()
    
    @staticmethod
    def compute_attachment_hash(content: bytes) -> str:
        """Compute SHA256 hash of attachment content.
        
        Args:
            content: Raw attachment bytes
            
        Returns:
            Hex-encoded SHA256 hash
        """
        return hashlib.sha256(content).hexdigest()
    
    @staticmethod
    def extract_thread_root_id(
        message_id: Optional[str],
        in_reply_to: Optional[str],
        references: Optional[str]
    ) -> str:
        """Extract thread root ID from email headers.
        
        RFC 5322 threading logic:
        - If References exists, first ID is root
        - Else if In-Reply-To exists, that's root
        - Else Message-ID is root (new thread)
        
        Args:
            message_id: Message-ID header
            in_reply_to: In-Reply-To header
            references: References header
            
        Returns:
            Thread root message ID
        """
        if references:
            # References is space-separated list, first is root
            refs = references.strip().split()
            if refs:
                return refs[0].strip('<>')
        
        if in_reply_to:
            return in_reply_to.strip('<>')
        
        if message_id:
            return message_id.strip('<>')
        
        # Fallback - shouldn't happen with valid emails
        return f"unknown-{datetime.utcnow().isoformat()}"
    
    def generate_idempotency_key(
        self,
        thread_root_id: str,
        attachment_hash: str
    ) -> str:
        """Generate idempotency key from thread and attachment.
        
        Args:
            thread_root_id: Root message ID of thread
            attachment_hash: SHA256 of attachment
            
        Returns:
            Idempotency key string
        """
        return f"{thread_root_id}:{attachment_hash}"
    
    def is_processed(self, idempotency_key: str) -> bool:
        """Check if item was already processed.
        
        Args:
            idempotency_key: Key to check
            
        Returns:
            True if already processed
        """
        with self._get_connection() as conn:
            cursor = conn.execute(
                "SELECT 1 FROM processed_items WHERE idempotency_key = ?",
                (idempotency_key,)
            )
            return cursor.fetchone() is not None
    
    def is_attachment_processed_in_thread(
        self,
        thread_root_id: str,
        attachment_hash: str
    ) -> Tuple[bool, Optional[str]]:
        """Check if attachment was already processed in this thread.
        
        Args:
            thread_root_id: Thread root ID
            attachment_hash: Attachment SHA256
            
        Returns:
            Tuple of (is_processed, existing_result_id)
        """
        key = self.generate_idempotency_key(thread_root_id, attachment_hash)
        
        with self._get_connection() as conn:
            cursor = conn.execute(
                """SELECT result_id FROM processed_items 
                   WHERE idempotency_key = ?""",
                (key,)
            )
            row = cursor.fetchone()
            if row:
                return True, row['result_id']
            return False, None
    
    def mark_processed(
        self,
        thread_root_id: str,
        message_id: str,
        attachment_hash: str,
        source_type: str,
        result_type: str,
        result_id: str,
        metadata: Optional[str] = None
    ) -> bool:
        """Mark item as processed.
        
        Args:
            thread_root_id: Thread root ID
            message_id: Current message ID
            attachment_hash: Attachment SHA256
            source_type: Source type (IAA/MANHEIM/COPART)
            result_type: Result type (clickup_task/cd_listing)
            result_id: Created task/listing ID
            metadata: Optional JSON metadata
            
        Returns:
            True if marked successfully, False if already exists
        """
        key = self.generate_idempotency_key(thread_root_id, attachment_hash)
        
        try:
            with self._get_connection() as conn:
                conn.execute(
                    """INSERT INTO processed_items 
                       (idempotency_key, thread_root_id, message_id, 
                        attachment_hash, source_type, result_type, 
                        result_id, metadata)
                       VALUES (?, ?, ?, ?, ?, ?, ?, ?)""",
                    (key, thread_root_id, message_id, attachment_hash,
                     source_type, result_type, result_id, metadata)
                )
                conn.commit()
                logger.info(f"Marked as processed: {key} -> {result_type}:{result_id}")
                return True
        except sqlite3.IntegrityError:
            logger.warning(f"Already processed: {key}")
            return False
    
    def get_stats(self) -> dict:
        """Get processing statistics.
        
        Returns:
            Dict with stats
        """
        with self._get_connection() as conn:
            cursor = conn.execute("""
                SELECT 
                    COUNT(*) as total,
                    COUNT(DISTINCT thread_root_id) as unique_threads,
                    source_type,
                    result_type
                FROM processed_items
                GROUP BY source_type, result_type
            """)
            
            stats = {"total": 0, "by_source": {}, "by_result": {}}
            for row in cursor:
                stats["total"] += row['total']
                source = row['source_type'] or 'unknown'
                result = row['result_type'] or 'unknown'
                stats["by_source"][source] = stats["by_source"].get(source, 0) + row['total']
                stats["by_result"][result] = stats["by_result"].get(result, 0) + row['total']
            
            return stats
