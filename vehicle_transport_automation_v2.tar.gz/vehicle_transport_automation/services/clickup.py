"""
ClickUp API client for creating vehicle pickup tasks.

API Documentation: https://clickup.com/api

Authentication: Personal API Token in Authorization header
Endpoint: POST /api/v2/list/{list_id}/task
"""
import os
import json
import logging
import time
from typing import Optional, Dict, Any, List
from dataclasses import dataclass
import requests

logger = logging.getLogger(__name__)


@dataclass
class ClickUpTask:
    """ClickUp task data."""
    name: str
    description: str
    priority: int = 3  # 1=urgent, 2=high, 3=normal, 4=low
    tags: Optional[List[str]] = None
    custom_fields: Optional[Dict[str, Any]] = None
    

class ClickUpClient:
    """Client for ClickUp API.
    
    Usage:
        client = ClickUpClient(
            token="pk_...",
            list_id="901317344729"
        )
        task_id = client.create_task(task)
    """
    
    API_BASE = "https://api.clickup.com/api/v2"
    
    def __init__(
        self,
        token: str,
        list_id: str,
        timeout: int = 30
    ):
        """Initialize ClickUp client.
        
        Args:
            token: Personal API token (starts with pk_)
            list_id: Target list ID for tasks
            timeout: Request timeout in seconds
        """
        self.token = token
        self.list_id = list_id
        self.timeout = timeout
        self._session = requests.Session()
        self._session.headers.update({
            "Authorization": token,
            "Content-Type": "application/json"
        })
    
    def _make_request(
        self,
        method: str,
        endpoint: str,
        data: Optional[Dict] = None,
        retries: int = 3
    ) -> requests.Response:
        """Make API request with retry logic.
        
        Args:
            method: HTTP method
            endpoint: API endpoint
            data: Request body
            retries: Number of retries
            
        Returns:
            Response object
        """
        url = f"{self.API_BASE}{endpoint}"
        
        for attempt in range(retries):
            try:
                response = self._session.request(
                    method=method,
                    url=url,
                    json=data,
                    timeout=self.timeout
                )
                
                # Rate limit handling
                if response.status_code == 429:
                    retry_after = int(response.headers.get('Retry-After', 60))
                    logger.warning(f"Rate limited, waiting {retry_after}s")
                    time.sleep(retry_after)
                    continue
                
                return response
                
            except requests.RequestException as e:
                logger.warning(f"Request failed (attempt {attempt + 1}/{retries}): {e}")
                if attempt < retries - 1:
                    time.sleep(2 ** attempt)  # Exponential backoff
                else:
                    raise
        
        raise ClickUpAPIError("Max retries exceeded")
    
    def create_task(self, task: ClickUpTask) -> Dict[str, Any]:
        """Create a new task in the configured list.
        
        Args:
            task: Task data
            
        Returns:
            Dict with task_id and response data
        """
        payload = {
            "name": task.name,
            "description": task.description,
            "priority": task.priority
        }
        
        if task.tags:
            payload["tags"] = task.tags
        
        if task.custom_fields:
            payload["custom_fields"] = [
                {"id": k, "value": v}
                for k, v in task.custom_fields.items()
            ]
        
        logger.info(f"Creating ClickUp task: {task.name}")
        
        response = self._make_request(
            "POST",
            f"/list/{self.list_id}/task",
            data=payload
        )
        
        if response.status_code in (200, 201):
            data = response.json()
            task_id = data.get("id")
            logger.info(f"Created ClickUp task: {task_id}")
            return {
                "success": True,
                "task_id": task_id,
                "url": data.get("url"),
                "response": data
            }
        else:
            error = self._parse_error(response)
            logger.error(f"Failed to create task: {error}")
            raise ClickUpAPIError(f"Failed to create task: {error}")
    
    def get_task(self, task_id: str) -> Dict[str, Any]:
        """Get task by ID.
        
        Args:
            task_id: Task ID
            
        Returns:
            Task data
        """
        response = self._make_request("GET", f"/task/{task_id}")
        
        if response.status_code == 200:
            return response.json()
        else:
            error = self._parse_error(response)
            raise ClickUpAPIError(f"Failed to get task: {error}")
    
    def update_task(
        self,
        task_id: str,
        updates: Dict[str, Any]
    ) -> Dict[str, Any]:
        """Update an existing task.
        
        Args:
            task_id: Task ID
            updates: Fields to update
            
        Returns:
            Updated task data
        """
        response = self._make_request(
            "PUT",
            f"/task/{task_id}",
            data=updates
        )
        
        if response.status_code == 200:
            return response.json()
        else:
            error = self._parse_error(response)
            raise ClickUpAPIError(f"Failed to update task: {error}")
    
    def add_comment(self, task_id: str, comment: str) -> Dict[str, Any]:
        """Add comment to task.
        
        Args:
            task_id: Task ID
            comment: Comment text
            
        Returns:
            Comment data
        """
        response = self._make_request(
            "POST",
            f"/task/{task_id}/comment",
            data={"comment_text": comment}
        )
        
        if response.status_code in (200, 201):
            return response.json()
        else:
            error = self._parse_error(response)
            raise ClickUpAPIError(f"Failed to add comment: {error}")
    
    def validate_credentials(self) -> bool:
        """Validate API token.
        
        Returns:
            True if token is valid
        """
        try:
            response = self._make_request("GET", "/user")
            return response.status_code == 200
        except Exception:
            return False
    
    def _parse_error(self, response: requests.Response) -> Dict[str, Any]:
        """Parse error response."""
        try:
            return response.json()
        except json.JSONDecodeError:
            return {"status": response.status_code, "message": response.text}


class ClickUpAPIError(Exception):
    """ClickUp API error."""
    pass


def create_client_from_env() -> ClickUpClient:
    """Create ClickUp client from environment variables.
    
    Expected env vars:
        CLICKUP_TOKEN: Personal API token
        CLICKUP_LIST_ID: Target list ID
    """
    token = os.environ.get("CLICKUP_TOKEN")
    list_id = os.environ.get("CLICKUP_LIST_ID")
    
    if not token:
        raise ValueError("CLICKUP_TOKEN environment variable required")
    if not list_id:
        raise ValueError("CLICKUP_LIST_ID environment variable required")
    
    return ClickUpClient(token=token, list_id=list_id)


def create_vehicle_pickup_task(
    client: ClickUpClient,
    vin: str,
    lot_number: str,
    vehicle_desc: str,
    pickup_address: str,
    gate_pass: Optional[str] = None,
    source: str = "UNKNOWN",
    additional_notes: Optional[str] = None
) -> Dict[str, Any]:
    """Helper to create a vehicle pickup task with standard format.
    
    Args:
        client: ClickUp client
        vin: Vehicle VIN
        lot_number: Lot/Stock number
        vehicle_desc: Vehicle description (Year Make Model)
        pickup_address: Pickup address
        gate_pass: Gate pass/PIN if available
        source: Source (IAA/MANHEIM/COPART)
        additional_notes: Any additional notes
        
    Returns:
        Created task data
    """
    # Build task name
    name = f"Pickup: {vehicle_desc} | LOT {lot_number}"
    
    # Build description
    desc_parts = [
        f"**Source:** {source}",
        f"**VIN:** {vin}",
        f"**Lot #:** {lot_number}",
        f"**Vehicle:** {vehicle_desc}",
        "",
        f"**Pickup Address:**",
        pickup_address
    ]
    
    if gate_pass:
        desc_parts.insert(4, f"**Gate Pass:** {gate_pass}")
    
    if additional_notes:
        desc_parts.extend(["", "**Notes:**", additional_notes])
    
    description = "\n".join(desc_parts)
    
    # Create task
    task = ClickUpTask(
        name=name,
        description=description,
        priority=3,
        tags=[source.lower()]
    )
    
    return client.create_task(task)
