#!/usr/bin/env python3
"""
Vehicle Transport Automation - Main Entry Point

Extracts vehicle data from auction invoices (IAA, Manheim, Copart)
and creates listings on Central Dispatch.

Usage:
    python main.py process <pdf_path> [--price PRICE] [--dry-run]
    python main.py batch <directory> [--price PRICE] [--dry-run]
    python main.py validate-credentials
"""
import os
import sys
import argparse
import json
import logging
from datetime import datetime, timedelta
from pathlib import Path
from typing import Optional

sys.path.insert(0, '/home/claude/vehicle_transport_automation')

from models.vehicle import (
    AuctionInvoice, TransportListing, Address, 
    TrailerType, AuctionSource
)
from extractors import extract_from_pdf, ExtractorManager
from services.central_dispatch import (
    CentralDispatchClient, create_client_from_env,
    AuthenticationError, APIError
)

# Configure logging
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s'
)
logger = logging.getLogger(__name__)


# Default delivery address (Broadway Motoring Inc)
DEFAULT_DELIVERY_ADDRESS = Address(
    name="Broadway Motoring Inc",
    street="77 Fitchburg Road",
    city="Ayer",
    state="MA",
    postal_code="01432",
    country="US"
)

# Default transport price (can be overridden)
DEFAULT_PRICE = 350.0


def process_invoice(
    pdf_path: str,
    price: float = DEFAULT_PRICE,
    delivery_address: Address = DEFAULT_DELIVERY_ADDRESS,
    dry_run: bool = False,
    cd_client: Optional[CentralDispatchClient] = None
) -> dict:
    """Process a single invoice PDF and create a Central Dispatch listing.
    
    Args:
        pdf_path: Path to the PDF file
        price: Transport price
        delivery_address: Delivery address
        dry_run: If True, don't actually create the listing
        cd_client: Central Dispatch client (optional for dry run)
        
    Returns:
        Dict with processing results
    """
    result = {
        "pdf_path": pdf_path,
        "success": False,
        "invoice": None,
        "listing": None,
        "error": None
    }
    
    # Extract invoice data
    logger.info(f"Processing: {pdf_path}")
    
    try:
        invoice = extract_from_pdf(pdf_path)
    except Exception as e:
        result["error"] = f"Failed to extract data: {e}"
        logger.error(result["error"])
        return result
    
    if not invoice:
        result["error"] = "Could not extract invoice data - document type not recognized"
        logger.error(result["error"])
        return result
    
    # Validate extracted data
    if not invoice.vehicles:
        result["error"] = "No vehicles found in invoice"
        logger.error(result["error"])
        return result
    
    if not invoice.pickup_address:
        result["error"] = "No pickup address found in invoice"
        logger.warning(result["error"])
        # Continue anyway - address might be added manually
    
    result["invoice"] = {
        "source": invoice.source.value,
        "buyer_id": invoice.buyer_id,
        "buyer_name": invoice.buyer_name,
        "reference_id": invoice.reference_id,
        "location_type": invoice.location_type.value,
        "vehicles": [
            {
                "vin": v.vin,
                "year": v.year,
                "make": v.make,
                "model": v.model,
                "vehicle_type": v.vehicle_type.value
            }
            for v in invoice.vehicles
        ],
        "pickup_address": {
            "name": invoice.pickup_address.name if invoice.pickup_address else None,
            "street": invoice.pickup_address.street if invoice.pickup_address else None,
            "city": invoice.pickup_address.city if invoice.pickup_address else None,
            "state": invoice.pickup_address.state if invoice.pickup_address else None,
            "postal_code": invoice.pickup_address.postal_code if invoice.pickup_address else None
        } if invoice.pickup_address else None
    }
    
    logger.info(f"Extracted: {invoice.source.value} - {invoice.vehicles[0].year} {invoice.vehicles[0].make} {invoice.vehicles[0].model}")
    
    # Create transport listing
    listing = TransportListing(
        invoice=invoice,
        delivery_address=delivery_address,
        price=price,
        trailer_type=TrailerType.OPEN,
        available_date=datetime.utcnow(),
        expiration_date=datetime.utcnow() + timedelta(days=14)
    )
    
    # Generate external ID for tracking
    listing.external_id = f"{invoice.source.value}-{invoice.reference_id or 'UNKNOWN'}"
    
    result["listing"] = listing.to_cd_listing()
    
    if dry_run:
        logger.info("Dry run - not creating listing")
        result["success"] = True
        result["dry_run"] = True
        return result
    
    # Create listing on Central Dispatch
    if not cd_client:
        try:
            cd_client = create_client_from_env()
        except ValueError as e:
            result["error"] = f"Central Dispatch credentials not configured: {e}"
            logger.error(result["error"])
            return result
    
    try:
        cd_result = cd_client.create_listing(listing)
        result["success"] = True
        result["listing_id"] = cd_result.get("listing_id")
        result["cd_response"] = cd_result
        logger.info(f"Created listing: {result['listing_id']}")
    except APIError as e:
        result["error"] = f"Failed to create listing: {e}"
        logger.error(result["error"])
    except AuthenticationError as e:
        result["error"] = f"Authentication failed: {e}"
        logger.error(result["error"])
    
    return result


def process_batch(
    directory: str,
    price: float = DEFAULT_PRICE,
    delivery_address: Address = DEFAULT_DELIVERY_ADDRESS,
    dry_run: bool = False
) -> list:
    """Process all PDF files in a directory.
    
    Args:
        directory: Directory containing PDF files
        price: Transport price
        delivery_address: Delivery address
        dry_run: If True, don't actually create listings
        
    Returns:
        List of processing results
    """
    results = []
    
    pdf_files = list(Path(directory).glob("*.pdf")) + list(Path(directory).glob("*.PDF"))
    
    if not pdf_files:
        logger.warning(f"No PDF files found in {directory}")
        return results
    
    logger.info(f"Found {len(pdf_files)} PDF files to process")
    
    # Create client once for all files
    cd_client = None
    if not dry_run:
        try:
            cd_client = create_client_from_env()
        except ValueError as e:
            logger.error(f"Central Dispatch credentials not configured: {e}")
    
    for pdf_path in pdf_files:
        result = process_invoice(
            str(pdf_path),
            price=price,
            delivery_address=delivery_address,
            dry_run=dry_run,
            cd_client=cd_client
        )
        results.append(result)
    
    # Summary
    successful = sum(1 for r in results if r["success"])
    failed = len(results) - successful
    logger.info(f"Batch complete: {successful} successful, {failed} failed")
    
    return results


def validate_credentials() -> bool:
    """Validate Central Dispatch API credentials.
    
    Returns:
        True if credentials are valid
    """
    try:
        client = create_client_from_env()
        if client.validate_credentials():
            logger.info("Credentials are valid")
            return True
        else:
            logger.error("Credentials are invalid")
            return False
    except ValueError as e:
        logger.error(f"Credentials not configured: {e}")
        return False


def main():
    """Main entry point."""
    parser = argparse.ArgumentParser(
        description="Vehicle Transport Automation - Process auction invoices and create Central Dispatch listings"
    )
    
    subparsers = parser.add_subparsers(dest="command", help="Command to run")
    
    # Process single file
    process_parser = subparsers.add_parser("process", help="Process a single PDF")
    process_parser.add_argument("pdf_path", help="Path to the PDF file")
    process_parser.add_argument("--price", type=float, default=DEFAULT_PRICE, help="Transport price")
    process_parser.add_argument("--dry-run", action="store_true", help="Don't create listing, just extract data")
    process_parser.add_argument("--output", "-o", help="Output file for results (JSON)")
    
    # Batch process
    batch_parser = subparsers.add_parser("batch", help="Process all PDFs in a directory")
    batch_parser.add_argument("directory", help="Directory containing PDF files")
    batch_parser.add_argument("--price", type=float, default=DEFAULT_PRICE, help="Transport price")
    batch_parser.add_argument("--dry-run", action="store_true", help="Don't create listings, just extract data")
    batch_parser.add_argument("--output", "-o", help="Output file for results (JSON)")
    
    # Validate credentials
    validate_parser = subparsers.add_parser("validate-credentials", help="Validate Central Dispatch credentials")
    
    # Extract only (for testing)
    extract_parser = subparsers.add_parser("extract", help="Extract data from PDF without creating listing")
    extract_parser.add_argument("pdf_path", help="Path to the PDF file")
    extract_parser.add_argument("--output", "-o", help="Output file for results (JSON)")
    
    args = parser.parse_args()
    
    if args.command == "process":
        result = process_invoice(args.pdf_path, price=args.price, dry_run=args.dry_run)
        
        if args.output:
            with open(args.output, 'w') as f:
                json.dump(result, f, indent=2, default=str)
        else:
            print(json.dumps(result, indent=2, default=str))
        
        sys.exit(0 if result["success"] else 1)
    
    elif args.command == "batch":
        results = process_batch(args.directory, price=args.price, dry_run=args.dry_run)
        
        if args.output:
            with open(args.output, 'w') as f:
                json.dump(results, f, indent=2, default=str)
        else:
            print(json.dumps(results, indent=2, default=str))
        
        successful = sum(1 for r in results if r["success"])
        sys.exit(0 if successful == len(results) else 1)
    
    elif args.command == "validate-credentials":
        success = validate_credentials()
        sys.exit(0 if success else 1)
    
    elif args.command == "extract":
        invoice = extract_from_pdf(args.pdf_path)
        
        if invoice:
            result = {
                "success": True,
                "source": invoice.source.value,
                "buyer_id": invoice.buyer_id,
                "buyer_name": invoice.buyer_name,
                "reference_id": invoice.reference_id,
                "location_type": invoice.location_type.value,
                "vehicles": [
                    {
                        "vin": v.vin,
                        "year": v.year,
                        "make": v.make,
                        "model": v.model,
                        "color": v.color,
                        "mileage": v.mileage,
                        "vehicle_type": v.vehicle_type.value,
                        "lot_number": v.lot_number
                    }
                    for v in invoice.vehicles
                ],
                "pickup_address": {
                    "name": invoice.pickup_address.name,
                    "street": invoice.pickup_address.street,
                    "city": invoice.pickup_address.city,
                    "state": invoice.pickup_address.state,
                    "postal_code": invoice.pickup_address.postal_code
                } if invoice.pickup_address else None,
                "total_amount": invoice.total_amount
            }
        else:
            result = {"success": False, "error": "Could not extract invoice data"}
        
        if args.output:
            with open(args.output, 'w') as f:
                json.dump(result, f, indent=2, default=str)
        else:
            print(json.dumps(result, indent=2, default=str))
        
        sys.exit(0 if result["success"] else 1)
    
    else:
        parser.print_help()
        sys.exit(1)


if __name__ == "__main__":
    main()
