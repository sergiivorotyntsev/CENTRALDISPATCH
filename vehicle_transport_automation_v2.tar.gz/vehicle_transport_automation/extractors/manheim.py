"""Manheim (Cox Automotive) document extractor."""
import re
from typing import Optional
from datetime import datetime

import sys
sys.path.insert(0, '/home/claude/vehicle_transport_automation')
from extractors.base import BaseExtractor
from models.vehicle import AuctionInvoice, Vehicle, Address, AuctionSource, LocationType, VehicleType


class ManheimExtractor(BaseExtractor):
    """Extractor for Manheim Bill of Sale and Vehicle Release documents."""
    
    @property
    def source(self) -> AuctionSource:
        return AuctionSource.MANHEIM
    
    def can_extract(self, text: str) -> bool:
        """Check if document is a Manheim document."""
        indicators = [
            'Manheim',
            'Cox Automotive',
            'BILL OF SALE',
            'VEHICLE RELEASE',
            'Manheim.com'
        ]
        return any(ind.lower() in text.lower() for ind in indicators)
    
    def extract(self, pdf_path: str) -> Optional[AuctionInvoice]:
        """Extract data from Manheim PDF."""
        pages_text = self.extract_pages_text(pdf_path)
        full_text = '\n'.join(pages_text)
        
        if not self.can_extract(full_text):
            return None
        
        invoice = AuctionInvoice(
            source=self.source,
            buyer_id="",
            buyer_name=""
        )
        
        # Extract buyer account number
        account_match = re.search(r'Account\s*#?\s*:?\s*(\d+)', full_text)
        if account_match:
            invoice.buyer_id = account_match.group(1)
        
        # Extract buyer name
        buyer_match = re.search(r'(?:Name|Buyer)\s+([A-Z][A-Za-z\s]+(?:INC|LLC|CORP|Inc|Llc|Corp)?)', full_text)
        if buyer_match:
            invoice.buyer_name = buyer_match.group(1).strip()
        
        # Extract sale date
        date_patterns = [
            r'Sale\s*Date\s+(\d{1,2}-[A-Z]{3}-\d{4})',
            r'Sale\s*Date\s+(\d{1,2}/\d{1,2}/\d{4})',
            r'Purchase\s*Date\s+[A-Za-z]+,\s+([A-Za-z]+\s+\d{1,2},\s+\d{4})'
        ]
        for pattern in date_patterns:
            date_match = re.search(pattern, full_text, re.IGNORECASE)
            if date_match:
                date_str = date_match.group(1)
                for fmt in ['%d-%b-%Y', '%m/%d/%Y', '%b %d, %Y']:
                    try:
                        invoice.sale_date = datetime.strptime(date_str, fmt)
                        break
                    except ValueError:
                        continue
                break
        
        # Determine ONSITE vs OFFSITE
        invoice.location_type = self._detect_location_type(full_text)
        
        # Extract Release ID
        release_match = re.search(r'Release\s*ID\s+([A-Z0-9]+)', full_text)
        if release_match:
            invoice.release_id = release_match.group(1)
        
        # Extract Work Order
        work_order_match = re.search(r'Work\s*Order\s*#?\s*:?\s*(\d+)', full_text)
        if work_order_match:
            invoice.stock_number = work_order_match.group(1)
        
        # Extract pickup location
        pickup_location = self._extract_pickup_location(full_text)
        if pickup_location:
            invoice.pickup_address = pickup_location
        
        # Extract vehicle info
        vehicle = self._extract_vehicle(full_text)
        if vehicle:
            invoice.vehicles.append(vehicle)
        
        # Extract total amount
        total_match = re.search(r'(?:Final\s*Sale\s*Price|TOTAL|SUB\s*TOTAL)\s*\$?\s*([\d,]+\.?\d*)', full_text, re.IGNORECASE)
        if total_match:
            try:
                invoice.total_amount = float(total_match.group(1).replace(',', ''))
            except ValueError:
                pass
        
        return invoice
    
    def _detect_location_type(self, text: str) -> LocationType:
        """Detect if vehicle is ONSITE or OFFSITE."""
        offsite_indicators = [
            'OFFSITE VEHICLE RELEASE',
            'not located at a Manheim facility',
            'This vehicle is not located at'
        ]
        for indicator in offsite_indicators:
            if indicator.lower() in text.lower():
                return LocationType.OFFSITE
        
        onsite_indicators = [
            'ONSITE VEHICLE RELEASE'
        ]
        for indicator in onsite_indicators:
            if indicator.lower() in text.lower():
                return LocationType.ONSITE
        
        return LocationType.ONSITE  # Default
    
    def _extract_pickup_location(self, text: str) -> Optional[Address]:
        """Extract pickup location from Manheim document."""
        # Look for Pickup Location section
        pickup_patterns = [
            # Standard format with Address label
            r'Pickup\s*Location\s+Address\s+([A-Za-z\s\-]+)\n\s*(\d+[A-Za-z0-9\s\.\-]+)\n\s*([A-Za-z\s]+),?\s*([A-Z]{2})\s+(\d{5}(?:-\d{4})?)',
            # Format without labels
            r'Address\s+(\d+[A-Za-z0-9\s\.\-]+)\n\s*([A-Za-z\s]+),?\s*([A-Z]{2})\s+(\d{5}(?:-\d{4})?)',
            # Manheim facility name
            r'(?:Manheim|MANHEIM)\s+([A-Za-z\-\s/]+)\n\s*(\d+[A-Za-z0-9\s\.\-]+)\n\s*([A-Za-z\s]+),?\s*([A-Z]{2})\s+(\d{5})'
        ]
        
        for pattern in pickup_patterns:
            match = re.search(pattern, text, re.IGNORECASE)
            if match:
                groups = match.groups()
                if len(groups) == 5:
                    return Address(
                        name=groups[0].strip(),
                        street=groups[1].strip(),
                        city=groups[2].strip(),
                        state=groups[3],
                        postal_code=groups[4],
                        country="US",
                        phone=self._extract_phone_near_location(text)
                    )
                elif len(groups) == 4:
                    return Address(
                        street=groups[0].strip(),
                        city=groups[1].strip(),
                        state=groups[2],
                        postal_code=groups[3],
                        country="US",
                        phone=self._extract_phone_near_location(text)
                    )
        
        return None
    
    def _extract_phone_near_location(self, text: str) -> Optional[str]:
        """Extract phone number near pickup location."""
        phone_match = re.search(r'Phone\s*Number\(?s?\)?\s*:?\s*\(?\d{3}\)?[-.\s]?\d{3}[-.\s]?\d{4}', text)
        if phone_match:
            return self.extract_phone(phone_match.group(0))
        return self.extract_phone(text)
    
    def _extract_vehicle(self, text: str) -> Optional[Vehicle]:
        """Extract vehicle information from Manheim document."""
        # Pattern for YMMT (Year Make Model Trim)
        ymmt_patterns = [
            r'YMMT\s+(\d{4})\s+([A-Za-z\-]+)\s+([A-Za-z0-9\s\-]+)',
            r'Vehicle\s*Information\s*\n.*?(\d{4})\s+([A-Za-z\-]+)\s+([A-Za-z0-9\s\-]+)',
            r'YEAR\s*MAKE\s*MODEL\s+(\d{4})\s+([A-Za-z\-]+)\s+([A-Za-z0-9\s]+)'
        ]
        
        year = None
        make = None
        model = None
        
        for pattern in ymmt_patterns:
            match = re.search(pattern, text, re.IGNORECASE)
            if match:
                year = int(match.group(1))
                make = match.group(2).strip()
                model = match.group(3).strip()
                break
        
        # Extract VIN
        vin = self.extract_vin(text)
        
        if not (year and make and vin):
            return None
        
        # Extract color
        color = None
        color_match = re.search(r'Color\s+([A-Za-z]+)', text)
        if color_match:
            color = color_match.group(1)
        
        # Extract mileage
        mileage = self.extract_mileage(text)
        
        return Vehicle(
            vin=vin,
            year=year,
            make=make,
            model=model or "Unknown",
            color=color,
            mileage=mileage,
            vehicle_type=self.detect_vehicle_type(make, model or "")
        )
