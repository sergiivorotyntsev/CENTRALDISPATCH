"""Copart document extractor."""
import re
from typing import Optional
from datetime import datetime

import sys
sys.path.insert(0, '/home/claude/vehicle_transport_automation')
from extractors.base import BaseExtractor
from models.vehicle import AuctionInvoice, Vehicle, Address, AuctionSource, LocationType, VehicleType


class CopartExtractor(BaseExtractor):
    """Extractor for Copart Sales Receipt/Bill of Sale documents."""
    
    @property
    def source(self) -> AuctionSource:
        return AuctionSource.COPART
    
    def can_extract(self, text: str) -> bool:
        """Check if document is a Copart document."""
        indicators = [
            'Copart',
            'Sales Receipt/Bill of Sale',
            'SOLD THROUGH COPART',
            'MEMBER:',
            'PHYSICAL ADDRESS OF LOT'
        ]
        return any(ind.lower() in text.lower() for ind in indicators)
    
    def extract(self, pdf_path: str) -> Optional[AuctionInvoice]:
        """Extract data from Copart Sales Receipt PDF."""
        text = self.extract_text(pdf_path)
        
        if not self.can_extract(text):
            return None
        
        invoice = AuctionInvoice(
            source=self.source,
            buyer_id="",
            buyer_name=""
        )
        
        # Extract Member ID
        member_match = re.search(r'MEMBER[:\s]+(\d+)', text)
        if member_match:
            invoice.buyer_id = member_match.group(1)
        
        # Extract buyer name (company name after MEMBER line)
        buyer_patterns = [
            r'MEMBER[:\s]+\d+\s+([A-Z][A-Za-z\s]+(?:INC|LLC|CORP|Inc|Llc|Corp)?)',
            r'([A-Z][A-Za-z\s]+(?:INC|LLC|CORP))\s+\d+\s+[A-Z]+\s+(?:ROAD|RD|STREET|ST)',
        ]
        for pattern in buyer_patterns:
            buyer_match = re.search(pattern, text)
            if buyer_match:
                invoice.buyer_name = buyer_match.group(1).strip()
                break
        
        # Extract LOT#
        lot_match = re.search(r'LOT#[:\s]+(\d+)', text)
        if lot_match:
            invoice.lot_number = lot_match.group(1)
        
        # Extract sale date
        date_patterns = [
            r'Sale[:\s]+(\d{1,2}/\d{1,2}/\d{4})',
            r'Date[:\s]+(\d{1,2}/\d{1,2}/\d{2,4})\s+\d{1,2}:\d{2}',
            r'(\d{1,2}/\d{1,2}/\d{4})'
        ]
        for pattern in date_patterns:
            date_match = re.search(pattern, text)
            if date_match:
                date_str = date_match.group(1)
                for fmt in ['%m/%d/%Y', '%m/%d/%y']:
                    try:
                        invoice.sale_date = datetime.strptime(date_str, fmt)
                        break
                    except ValueError:
                        continue
                if invoice.sale_date:
                    break
        
        # Extract pickup location (PHYSICAL ADDRESS OF LOT)
        pickup_location = self._extract_pickup_location(text)
        if pickup_location:
            invoice.pickup_address = pickup_location
        
        # Extract vehicle info
        vehicle = self._extract_vehicle(text)
        if vehicle:
            vehicle.lot_number = invoice.lot_number
            invoice.vehicles.append(vehicle)
        
        # Extract total amount
        total_patterns = [
            r'Sale\s*Price\s*\$?([\d,]+\.?\d*)',
            r'Net\s*Due\s*\(USD\)\s*\$?([\d,]+\.?\d*)'
        ]
        for pattern in total_patterns:
            total_match = re.search(pattern, text, re.IGNORECASE)
            if total_match:
                try:
                    invoice.total_amount = float(total_match.group(1).replace(',', ''))
                    if invoice.total_amount > 0:
                        break
                except ValueError:
                    pass
        
        # Copart lots are always ONSITE at their facilities
        invoice.location_type = LocationType.ONSITE
        
        return invoice
    
    def _extract_pickup_location(self, text: str) -> Optional[Address]:
        """Extract pickup location from Copart document."""
        # Look for PHYSICAL ADDRESS OF LOT section
        # Pattern: PHYSICAL ADDRESS OF LOT: followed by street, city state zip
        patterns = [
            # Format: PHYSICAL ADDRESS OF LOT:\nStreet\nCity State Zip
            r'PHYSICAL\s*ADDRESS\s*(?:OF\s*)?LOT[:\s]+([^\n]+)\n\s*([A-Za-z\s]+)\s+([A-Z]{2})\s+(\d{5})',
            # Alternative: Address on same line
            r'PHYSICAL\s*ADDRESS\s*(?:OF\s*)?LOT[:\s]+(\d+[A-Za-z0-9\s\.\-,]+?)\s+([A-Za-z\s]+)\s+([A-Z]{2})\s+(\d{5})'
        ]
        
        for pattern in patterns:
            match = re.search(pattern, text, re.IGNORECASE)
            if match:
                groups = match.groups()
                return Address(
                    street=groups[0].strip(),
                    city=groups[1].strip(),
                    state=groups[2],
                    postal_code=groups[3],
                    country="US",
                    name="Copart"
                )
        
        # Try to find address after PHYSICAL ADDRESS OF LOT
        alt_pattern = r'PHYSICAL\s*ADDRESS\s*(?:OF\s*)?LOT[:\s]+\n?([^\n]+)'
        alt_match = re.search(alt_pattern, text, re.IGNORECASE)
        if alt_match:
            address_text = alt_match.group(1)
            # Parse city, state, zip from the address text
            city_state_zip = re.search(r'([A-Za-z\s]+)\s+([A-Z]{2})\s+(\d{5})', address_text)
            if city_state_zip:
                return Address(
                    street=address_text.split(city_state_zip.group(1))[0].strip(),
                    city=city_state_zip.group(1).strip(),
                    state=city_state_zip.group(2),
                    postal_code=city_state_zip.group(3),
                    country="US",
                    name="Copart"
                )
        
        return None
    
    def _extract_vehicle(self, text: str) -> Optional[Vehicle]:
        """Extract vehicle information from Copart document."""
        # Pattern for VEHICLE line: YEAR MAKE MODEL TRIM COLOR
        # Example: 2024 HYUNDAI TUCSON SEL BLACK
        vehicle_patterns = [
            r'VEHICLE[:\s]+(\d{4})\s+([A-Z]+(?:\-[A-Z]+)?)\s+([A-Z0-9\s\-]+?)\s+(BLACK|WHITE|SILVER|GRAY|GREY|RED|BLUE|GREEN|BROWN|GOLD|BEIGE|TAN|ORANGE|YELLOW|PURPLE|MAROON)',
            r'VEHICLE[:\s]+(\d{4})\s+([A-Z]+(?:\-[A-Z]+)?)\s+([A-Z0-9\s\-]+)',
        ]
        
        year = None
        make = None
        model = None
        color = None
        
        for pattern in vehicle_patterns:
            match = re.search(pattern, text, re.IGNORECASE)
            if match:
                year = int(match.group(1))
                make = match.group(2).strip()
                # Clean up model - remove trailing color if present
                model_raw = match.group(3).strip()
                # Remove common color words from end of model
                colors = ['BLACK', 'WHITE', 'SILVER', 'GRAY', 'GREY', 'RED', 'BLUE', 'GREEN', 'BROWN', 'GOLD', 'BEIGE', 'TAN']
                for c in colors:
                    if model_raw.upper().endswith(c):
                        model_raw = model_raw[:-len(c)].strip()
                        color = c.capitalize()
                        break
                model = model_raw
                
                # Check if color is in 4th group
                if len(match.groups()) > 3 and match.group(4):
                    color = match.group(4).capitalize()
                break
        
        # Extract VIN
        vin = self.extract_vin(text)
        
        if not (year and make and vin):
            # Try alternative extraction
            vin = self.extract_vin(text)
            year_match = re.search(r'\b(20\d{2}|19\d{2})\b', text)
            if year_match and vin:
                year = int(year_match.group(1))
                # Try to get make from text near VIN
                make_pattern = r'(\d{4})\s+([A-Z]+(?:\-[A-Z]+)?)\s+'
                make_match = re.search(make_pattern, text, re.IGNORECASE)
                if make_match:
                    make = make_match.group(2)
                    model = "Unknown"
                else:
                    return None
            else:
                return None
        
        # Extract mileage
        mileage = self.extract_mileage(text)
        
        # Check for Keys status
        keys_match = re.search(r'Keys[:\s]+(YES|NO)', text, re.IGNORECASE)
        notes = f"Keys: {keys_match.group(1)}" if keys_match else None
        
        vehicle = Vehicle(
            vin=vin,
            year=year,
            make=make.title() if make else "Unknown",
            model=model.title() if model else "Unknown",
            color=color,
            mileage=mileage,
            vehicle_type=self.detect_vehicle_type(make or "", model or "")
        )
        
        return vehicle
