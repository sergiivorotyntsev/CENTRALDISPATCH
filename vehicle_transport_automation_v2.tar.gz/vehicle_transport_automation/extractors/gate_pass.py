"""
Gate Pass / PIN extractor from email body.

Extracts gate pass codes from email text/HTML body.
Supports various formats from IAA, Manheim, Copart.
"""
import re
import logging
from typing import Optional, List, Tuple
from dataclasses import dataclass

logger = logging.getLogger(__name__)


@dataclass
class GatePassInfo:
    """Extracted gate pass information."""
    code: str
    raw_match: str
    source_hint: Optional[str] = None  # IAA/MANHEIM/COPART if detectable


class GatePassExtractor:
    """Extracts gate pass/PIN codes from email body text."""
    
    # Patterns for various gate pass formats
    PATTERNS = [
        # Standard "Gate Pass: XXXXX" format
        (r'Gate\s*Pass\s*(?:Pin|Code|#|Number)?\s*[:#]?\s*([A-Za-z0-9\-]{4,20})', 'generic'),
        
        # IAA format
        (r'(?:IAA|IAAI)\s*(?:Gate\s*)?Pass\s*[:#]?\s*([A-Za-z0-9\-]{4,20})', 'IAA'),
        
        # Copart format - often "Release Code" or "Lot Release"
        (r'(?:Release|Lot)\s*(?:Code|#|Pin)\s*[:#]?\s*([A-Za-z0-9\-]{4,20})', 'COPART'),
        
        # Manheim format - "Release ID" or "Pickup Code"
        (r'(?:Release\s*ID|Pickup\s*Code|Pickup\s*Pin)\s*[:#]?\s*([A-Za-z0-9\-]{4,20})', 'MANHEIM'),
        
        # PIN format
        (r'(?:Pickup|Gate|Access)\s*PIN\s*[:#]?\s*([A-Za-z0-9\-]{4,20})', 'generic'),
        
        # Authorization code
        (r'Auth(?:orization)?\s*Code\s*[:#]?\s*([A-Za-z0-9\-]{4,20})', 'generic'),
        
        # Pass code format
        (r'Pass\s*(?:Code|#)\s*[:#]?\s*([A-Za-z0-9\-]{4,20})', 'generic'),
        
        # Standalone code after "code:" or "pin:"
        (r'\b(?:code|pin)\s*[:#]\s*([A-Za-z0-9\-]{4,20})\b', 'generic'),
    ]
    
    # Words that indicate the code is NOT a gate pass
    EXCLUDE_WORDS = [
        'tracking', 'confirmation', 'order', 'invoice', 
        'receipt', 'reference', 'account', 'member',
        'customer', 'buyer', 'stock', 'vin'
    ]
    
    @classmethod
    def extract_from_text(cls, text: str) -> List[GatePassInfo]:
        """Extract all gate pass codes from text.
        
        Args:
            text: Email body text
            
        Returns:
            List of extracted gate pass info
        """
        results = []
        seen_codes = set()
        
        # Normalize text
        text_lower = text.lower()
        
        for pattern, source_hint in cls.PATTERNS:
            matches = re.finditer(pattern, text, re.IGNORECASE)
            
            for match in matches:
                code = match.group(1).strip()
                raw_match = match.group(0).strip()
                
                # Normalize code
                normalized = cls._normalize_code(code)
                
                # Skip if already seen
                if normalized in seen_codes:
                    continue
                
                # Skip if looks like excluded type
                context = text_lower[max(0, match.start()-50):match.end()+50]
                if cls._is_excluded_context(context):
                    continue
                
                # Validate code format
                if cls._is_valid_code(normalized):
                    seen_codes.add(normalized)
                    results.append(GatePassInfo(
                        code=normalized,
                        raw_match=raw_match,
                        source_hint=source_hint if source_hint != 'generic' else None
                    ))
        
        return results
    
    @classmethod
    def extract_primary(cls, text: str) -> Optional[str]:
        """Extract the most likely gate pass code.
        
        Args:
            text: Email body text
            
        Returns:
            Primary gate pass code or None
        """
        results = cls.extract_from_text(text)
        
        if not results:
            return None
        
        # Prefer codes with source hints
        for r in results:
            if r.source_hint:
                return r.code
        
        # Return first match
        return results[0].code
    
    @staticmethod
    def _normalize_code(code: str) -> str:
        """Normalize gate pass code.
        
        - Remove surrounding whitespace
        - Uppercase
        - Keep hyphens (some codes use them)
        """
        return code.strip().upper()
    
    @classmethod
    def _is_excluded_context(cls, context: str) -> bool:
        """Check if context suggests this is not a gate pass."""
        for word in cls.EXCLUDE_WORDS:
            # Check if excluded word is right before the match
            if word in context:
                # Pattern: "tracking code: XXX" should be excluded
                pattern = rf'{word}\s*(?:code|#|number|id)\s*[:#]'
                if re.search(pattern, context, re.IGNORECASE):
                    return True
        return False
    
    @staticmethod
    def _is_valid_code(code: str) -> bool:
        """Validate that code looks like a gate pass.
        
        Valid codes:
        - 4-20 characters
        - Alphanumeric (with optional hyphens)
        - Not common words
        """
        if len(code) < 4 or len(code) > 20:
            return False
        
        # Must be alphanumeric (with hyphens allowed)
        if not re.match(r'^[A-Z0-9\-]+$', code):
            return False
        
        # Exclude common words
        common_words = {'CODE', 'PASS', 'GATE', 'PIN', 'NONE', 'NULL', 'TEST'}
        if code in common_words:
            return False
        
        return True


def extract_text_from_email_body(msg) -> str:
    """Extract plain text from email message body.
    
    Handles:
    - text/plain parts
    - text/html parts (converts to text)
    - multipart messages
    
    Args:
        msg: email.message.Message object
        
    Returns:
        Combined text from all text parts
    """
    text_parts = []
    
    if msg.is_multipart():
        for part in msg.walk():
            content_type = part.get_content_type()
            
            if content_type == 'text/plain':
                payload = part.get_payload(decode=True)
                if payload:
                    charset = part.get_content_charset() or 'utf-8'
                    try:
                        text_parts.append(payload.decode(charset, errors='replace'))
                    except Exception:
                        text_parts.append(payload.decode('utf-8', errors='replace'))
            
            elif content_type == 'text/html':
                payload = part.get_payload(decode=True)
                if payload:
                    charset = part.get_content_charset() or 'utf-8'
                    try:
                        html = payload.decode(charset, errors='replace')
                    except Exception:
                        html = payload.decode('utf-8', errors='replace')
                    
                    # Convert HTML to text
                    text_parts.append(_html_to_text(html))
    else:
        content_type = msg.get_content_type()
        payload = msg.get_payload(decode=True)
        
        if payload:
            charset = msg.get_content_charset() or 'utf-8'
            try:
                content = payload.decode(charset, errors='replace')
            except Exception:
                content = payload.decode('utf-8', errors='replace')
            
            if content_type == 'text/html':
                content = _html_to_text(content)
            
            text_parts.append(content)
    
    return '\n\n'.join(text_parts)


def _html_to_text(html: str) -> str:
    """Convert HTML to plain text.
    
    Simple conversion without external dependencies.
    For better results, use beautifulsoup4 or html2text.
    """
    import re
    
    # Remove script and style elements
    text = re.sub(r'<script[^>]*>.*?</script>', '', html, flags=re.DOTALL | re.IGNORECASE)
    text = re.sub(r'<style[^>]*>.*?</style>', '', text, flags=re.DOTALL | re.IGNORECASE)
    
    # Convert line breaks
    text = re.sub(r'<br\s*/?>', '\n', text, flags=re.IGNORECASE)
    text = re.sub(r'<p[^>]*>', '\n', text, flags=re.IGNORECASE)
    text = re.sub(r'</p>', '\n', text, flags=re.IGNORECASE)
    text = re.sub(r'<div[^>]*>', '\n', text, flags=re.IGNORECASE)
    text = re.sub(r'</div>', '\n', text, flags=re.IGNORECASE)
    
    # Remove remaining tags
    text = re.sub(r'<[^>]+>', '', text)
    
    # Decode HTML entities
    text = text.replace('&nbsp;', ' ')
    text = text.replace('&amp;', '&')
    text = text.replace('&lt;', '<')
    text = text.replace('&gt;', '>')
    text = text.replace('&quot;', '"')
    text = text.replace('&#39;', "'")
    
    # Normalize whitespace
    text = re.sub(r'\n\s*\n', '\n\n', text)
    text = re.sub(r' +', ' ', text)
    
    return text.strip()
